#!/usr/bin/env python3
"""
verify_retrain.py - приёмочная проверка свежеобученных моделей.

Запускается из auto_retrain_transformer.sh после обучения. Берёт N последних
matched_forecast_obs дат, гоняет на них ансамбль трансформера и XGBoost,
сравнивает с WRF. Первая строка stdout: "PASS: ..." или "FAIL: ...".

Критерии PASS (все одновременно):
  |bias_ensemble| < 1.0
  MAE_ensemble ≤ MAE_wrf * 1.05
  |bias_xgb| < 0.7
  MAE_xgb < MAE_wrf

Дополнительно: OOS-тест XGBoost на датах строго после max(training_dates) pkl.
Если OOS-дат нет - только предупреждение. Если есть - применяет более мягкие пороги:
  |bias_xgb_oos| < 1.5
  MAE_xgb_oos < MAE_wrf_oos * 1.10
Провал OOS-теста выдаёт FAIL и блокирует деплой.
"""

import glob
import os
import pickle
import sys
import traceback

import numpy as np
import pandas as pd

sys.path.insert(0, "/data/scripts/transformer")
sys.path.insert(0, "/data/scripts")

RETRO_DIR = "/data/weather_output/retrospective"
OBS_CSV = "/data/weather_data/observations/fact_obs_combined.csv"
STATIONS_CSV = "/data/stations/all_stations.csv"
XGB_PKL = "/data/weather_output/ml/xgboost_bias_correction.pkl"
N_DATES = 4

# Критерии PASS (in-sample acceptance)
THR_BIAS_ENS = 1.0
THR_MAE_ENS_RATIO = 1.05
THR_BIAS_XGB = 0.7

# Критерии OOS-теста XGB (более мягкие - распределение чуть сдвигается)
THR_OOS_BIAS_XGB = 1.5
THR_OOS_MAE_XGB_RATIO = 1.10


def _xgb_add_features(df: pd.DataFrame, date_str: str) -> pd.DataFrame:
    """Репликация train_xgboost_bias.add_features()."""
    df = df.copy()
    df["datetime"] = pd.to_datetime(df["datetime"])
    h = df["datetime"].dt.hour
    df["hour_sin"] = np.sin(2 * np.pi * h / 24)
    df["hour_cos"] = np.cos(2 * np.pi * h / 24)
    doy = df["datetime"].dt.dayofyear
    df["day_sin"] = np.sin(2 * np.pi * doy / 365)
    df["day_cos"] = np.cos(2 * np.pi * doy / 365)
    init_dt = pd.Timestamp(f"{date_str[:4]}-{date_str[4:6]}-{date_str[6:8]} 00:00:00")
    df["forecast_hour"] = (df["datetime"] - init_dt).dt.total_seconds() / 3600
    df["wind_speed"] = np.sqrt(df["windU_stn"]**2 + df["windV_stn"]**2)
    spd = df["wind_speed"].replace(0, np.nan)
    df["wind_dir_sin"] = (df["windU_stn"] / spd).fillna(0.0)
    df["wind_dir_cos"] = (df["windV_stn"] / spd).fillna(0.0)
    df["date_str"] = date_str
    df = df.sort_values(["rep_id", "date_str", "datetime"])
    df["temp_trend"] = df.groupby(["rep_id", "date_str"])["temp_stn"].diff().fillna(0.0)
    df["pressure_tendency"] = df.groupby(["rep_id", "date_str"])["pressure_stn"].diff().fillna(0.0)
    df["elevation_proxy"] = -8000.0 * np.log(df["pressure_stn"] / 1013.25)
    df["forecast_hour_sq"] = df["forecast_hour"] ** 2
    df["forecast_hour_cub"] = df["forecast_hour"] ** 3
    month = df["datetime"].dt.month
    df["month_sin"] = np.sin(2 * np.pi * month / 12)
    df["month_cos"] = np.cos(2 * np.pi * month / 12)
    df["temp_x_fhour"] = df["temp_stn"] * df["forecast_hour"]
    df["ptend_x_wind"] = df["pressure_tendency"] * df["wind_speed"]
    df["temp_stn_lag3h"] = df.groupby(["rep_id", "date_str"])["temp_stn"].shift(1).fillna(df["temp_stn"])
    df["pressure_stn_lag3h"] = df.groupby(["rep_id", "date_str"])["pressure_stn"].shift(1).fillna(df["pressure_stn"])
    return df


def _fail(msg: str, code: int = 2) -> int:
    print(f"FAIL: {msg}")
    return code


def _last_dates(n: int) -> list:
    files = sorted(glob.glob(os.path.join(RETRO_DIR, "matched_forecast_obs_????????.csv")))
    if not files:
        return []
    dates = [os.path.basename(f)[len("matched_forecast_obs_"):-len(".csv")] for f in files]
    return dates[-n:]


def _oos_dates() -> tuple[list, str | None]:
    """Возвращает (даты строго после max_training_date, max_training_date или None)."""
    try:
        with open(XGB_PKL, "rb") as f:
            bundle = pickle.load(f)
        max_t = str(max(bundle["training_dates"]))
    except Exception:
        return [], None
    files = sorted(glob.glob(os.path.join(RETRO_DIR, "matched_forecast_obs_????????.csv")))
    oos = []
    for f in files:
        d = os.path.basename(f)[len("matched_forecast_obs_"):-len(".csv")]
        if d > max_t:
            oos.append(d)
    return oos, max_t


def main() -> int:
    dates = _last_dates(N_DATES)
    if len(dates) < 2:
        return _fail(f"только {len(dates)} matched дат - недостаточно")

    # Загрузка зависимостей
    try:
        from apply_ensemble import ensemble_predict
    except Exception as e:
        return _fail(f"не импортируется apply_ensemble: {e}")

    try:
        with open(XGB_PKL, "rb") as f:
            bundle = pickle.load(f)
        xgb_model = bundle["model"]
        xgb_feats = bundle["feature_cols"]
        station_bias = bundle["station_mean_bias"]
        global_bias = bundle["global_mean_bias"]
        feat_pct = bundle.get("feature_percentiles", {})
    except Exception as e:
        return _fail(f"не загружается XGBoost: {e}")

    obs = pd.read_csv(OBS_CSV)
    obs["datetime"] = pd.to_datetime(obs["datetime"])
    obs = obs.dropna(subset=["temp_obs"])

    stn = pd.read_csv(STATIONS_CSV)[["IndexNbr", "lat", "lon"]].rename(columns={"IndexNbr": "rep_id"})

    rows = []
    for date_str in dates:
        wrf_csv = os.path.join(RETRO_DIR, f"wrf_forecast_{date_str}.csv")
        if not os.path.exists(wrf_csv):
            print(f"  skip {date_str}: нет WRF CSV", flush=True)
            continue

        wrf = pd.read_csv(wrf_csv)
        wrf["datetime"] = pd.to_datetime(wrf["forecast_date"].str.replace("_", " "))

        # Ensemble inference
        try:
            df_ens = ensemble_predict(wrf_csv, STATIONS_CSV)
        except Exception as e:
            traceback.print_exc()
            return _fail(f"ensemble_predict упал на {date_str}: {e}")
        if df_ens is None:
            return _fail(f"ensemble_predict вернул None на {date_str}")

        # Merge ENS + полный WRF (нужны windU/windV/rain/pressure для XGB фич) + obs
        wrf_full = wrf[["rep_id", "datetime", "temp_stn", "rain_stn",
                        "windU_stn", "windV_stn", "pressure_stn"]]
        m = df_ens.merge(wrf_full, on=["rep_id", "datetime"], how="inner") \
                  .merge(obs[["rep_id", "datetime", "temp_obs"]], on=["rep_id", "datetime"], how="inner")
        m = m.dropna(subset=["temp_stn", "temp_ml", "temp_obs"])
        if len(m) < 100:
            print(f"  skip {date_str}: только {len(m)} пар", flush=True)
            continue

        err_wrf = (m["temp_stn"] - m["temp_obs"]).values
        err_ens = (m["temp_ml"] - m["temp_obs"]).values

        # XGBoost inference на тех же строках
        mx = m.merge(stn, on="rep_id", how="left")
        mx = mx.dropna(subset=["lat", "lon", "windU_stn", "windV_stn", "pressure_stn"])
        mx["error"] = mx["temp_stn"] - mx["temp_obs"]
        mx = _xgb_add_features(mx, date_str)
        mx["mean_bias_station"] = mx["rep_id"].map(station_bias).fillna(global_bias)
        mx = mx.dropna(subset=xgb_feats)
        for col, (lo, hi) in feat_pct.items():
            if col in mx.columns:
                mx[col] = mx[col].clip(lower=lo, upper=hi)

        if len(mx) < 100:
            print(f"  skip {date_str}: XGB только {len(mx)} строк", flush=True)
            continue

        X = mx[xgb_feats].values
        pred_err = np.clip(xgb_model.predict(X), -8.0, 8.0)
        temp_xgb = mx["temp_stn"].values - pred_err
        err_xgb = temp_xgb - mx["temp_obs"].values
        err_wrf_xgb = (mx["temp_stn"].values - mx["temp_obs"].values)

        rows.append({
            "date": date_str,
            "n_ens": len(m),
            "bias_wrf": err_wrf.mean(),
            "bias_ens": err_ens.mean(),
            "mae_wrf": np.abs(err_wrf).mean(),
            "mae_ens": np.abs(err_ens).mean(),
            "n_xgb": len(mx),
            "bias_xgb": err_xgb.mean(),
            "mae_xgb": np.abs(err_xgb).mean(),
            "mae_wrf_xgb": np.abs(err_wrf_xgb).mean(),
        })

    if not rows:
        return _fail("нет дат для верификации")

    df = pd.DataFrame(rows)
    bias_ens = df["bias_ens"].mean()
    mae_ens = df["mae_ens"].mean()
    mae_wrf = df["mae_wrf"].mean()
    bias_xgb = df["bias_xgb"].mean()
    mae_xgb = df["mae_xgb"].mean()
    mae_wrf_xgb = df["mae_wrf_xgb"].mean()

    metrics = (f"ENS bias={bias_ens:+.2f} MAE={mae_ens:.2f} (WRF MAE={mae_wrf:.2f}); "
               f"XGB bias={bias_xgb:+.2f} MAE={mae_xgb:.2f} (WRF MAE={mae_wrf_xgb:.2f}); "
               f"на {len(df)} датах")

    reasons = []
    if not np.isfinite(bias_ens) or abs(bias_ens) >= THR_BIAS_ENS:
        reasons.append(f"|bias_ens|={abs(bias_ens):.2f} ≥ {THR_BIAS_ENS}")
    if not np.isfinite(mae_ens) or mae_ens > mae_wrf * THR_MAE_ENS_RATIO:
        reasons.append(f"MAE_ens={mae_ens:.2f} > WRF*{THR_MAE_ENS_RATIO} ({mae_wrf*THR_MAE_ENS_RATIO:.2f})")
    if not np.isfinite(bias_xgb) or abs(bias_xgb) >= THR_BIAS_XGB:
        reasons.append(f"|bias_xgb|={abs(bias_xgb):.2f} ≥ {THR_BIAS_XGB}")
    if not np.isfinite(mae_xgb) or mae_xgb >= mae_wrf_xgb:
        reasons.append(f"MAE_xgb={mae_xgb:.2f} ≥ WRF MAE {mae_wrf_xgb:.2f}")

    if reasons:
        print(f"FAIL: {'; '.join(reasons)} | {metrics}")
        for _, r in df.iterrows():
            print(f"  {r['date']}: ENS bias={r['bias_ens']:+.2f} MAE={r['mae_ens']:.2f} | "
                  f"XGB bias={r['bias_xgb']:+.2f} MAE={r['mae_xgb']:.2f} | "
                  f"WRF MAE={r['mae_wrf']:.2f}")
        return 1

    # OOS-тест XGB: даты строго после max(training_dates) в pkl
    oos_dates, max_t = _oos_dates()
    if not oos_dates:
        print(f"  [OOS] нет дат после max_training={max_t} - OOS-тест пропущен")
    else:
        print(f"  [OOS] тестируем XGB на {len(oos_dates)} датах после {max_t}: {oos_dates}", flush=True)
        oos_rows = []
        for date_str in oos_dates:
            wrf_csv = os.path.join(RETRO_DIR, f"wrf_forecast_{date_str}.csv")
            matched_csv = os.path.join(RETRO_DIR, f"matched_forecast_obs_{date_str}.csv")
            if not os.path.exists(wrf_csv) or not os.path.exists(matched_csv):
                print(f"  [OOS] skip {date_str}: нет файлов", flush=True)
                continue
            try:
                m = pd.read_csv(matched_csv)
                m["datetime"] = pd.to_datetime(m["datetime"])
                m = m.dropna(subset=["temp_stn", "temp_obs"])
                if len(m) < 50:
                    print(f"  [OOS] skip {date_str}: только {len(m)} строк", flush=True)
                    continue
                mx = m.merge(stn, on="rep_id", how="left")
                mx = mx.dropna(subset=["lat", "lon", "windU_stn", "windV_stn", "pressure_stn"])
                mx["error"] = mx["temp_stn"] - mx["temp_obs"]
                mx = _xgb_add_features(mx, date_str)
                mx["mean_bias_station"] = mx["rep_id"].map(station_bias).fillna(global_bias)
                mx = mx.dropna(subset=xgb_feats)
                for col, (lo, hi) in feat_pct.items():
                    if col in mx.columns:
                        mx[col] = mx[col].clip(lower=lo, upper=hi)
                if len(mx) < 50:
                    print(f"  [OOS] skip {date_str}: XGB только {len(mx)} строк", flush=True)
                    continue
                X = mx[xgb_feats].values
                pred_err = np.clip(xgb_model.predict(X), -8.0, 8.0)
                temp_xgb = mx["temp_stn"].values - pred_err
                err_xgb = temp_xgb - mx["temp_obs"].values
                err_wrf = mx["temp_stn"].values - mx["temp_obs"].values
                oos_rows.append({
                    "date": date_str,
                    "bias_xgb": err_xgb.mean(),
                    "mae_xgb": np.abs(err_xgb).mean(),
                    "mae_wrf": np.abs(err_wrf).mean(),
                })
                print(f"  [OOS] {date_str}: XGB bias={err_xgb.mean():+.2f} MAE={np.abs(err_xgb).mean():.2f} "
                      f"WRF MAE={np.abs(err_wrf).mean():.2f}", flush=True)
            except Exception as e:
                print(f"  [OOS] {date_str}: ошибка - {e}", flush=True)

        if oos_rows:
            oos_df = pd.DataFrame(oos_rows)
            oos_bias = oos_df["bias_xgb"].mean()
            oos_mae = oos_df["mae_xgb"].mean()
            oos_wrf = oos_df["mae_wrf"].mean()
            oos_reasons = []
            if not np.isfinite(oos_bias) or abs(oos_bias) >= THR_OOS_BIAS_XGB:
                oos_reasons.append(f"|bias_xgb_oos|={abs(oos_bias):.2f} ≥ {THR_OOS_BIAS_XGB}")
            if not np.isfinite(oos_mae) or oos_mae >= oos_wrf * THR_OOS_MAE_XGB_RATIO:
                oos_reasons.append(f"MAE_xgb_oos={oos_mae:.2f} ≥ WRF*{THR_OOS_MAE_XGB_RATIO} ({oos_wrf*THR_OOS_MAE_XGB_RATIO:.2f})")
            if oos_reasons:
                print(f"FAIL: OOS-тест XGB провален ({'; '.join(oos_reasons)}) | "
                      f"OOS: bias={oos_bias:+.2f} MAE={oos_mae:.2f} WRF={oos_wrf:.2f} на {len(oos_df)} датах")
                return 1
            print(f"  [OOS] OK: bias={oos_bias:+.2f} MAE={oos_mae:.2f} WRF={oos_wrf:.2f} ({len(oos_df)} дат)")

    print(f"PASS: {metrics}")
    for _, r in df.iterrows():
        print(f"  {r['date']}: ENS bias={r['bias_ens']:+.2f} MAE={r['mae_ens']:.2f} | "
              f"XGB bias={r['bias_xgb']:+.2f} MAE={r['mae_xgb']:.2f} | "
              f"WRF MAE={r['mae_wrf']:.2f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
