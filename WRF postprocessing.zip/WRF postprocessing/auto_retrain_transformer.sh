#!/bin/bash
# Автоматическое дообучение трансформера на новых фактических данных
#
# Пайплайн:
#   1. Скачать новые xlsx с SFTP
#   2. Конвертировать xlsx → observations CSV
#   3. Сматчить с WRF прогнозами
#   4. Если накопилось NEW_DATES_THRESHOLD новых дат - дообучить модель
#
# Запуск: /data/scripts/auto_retrain_transformer.sh
# Крон:   0 22 * * 0 /data/scripts/auto_retrain_transformer.sh  (воскресенье 22:00 UTC - после всех SFTP)

set -euo pipefail

SCRIPTS_DIR="/data/scripts"
LOG_DIR="/data/weather_output/logs"
LOG="${LOG_DIR}/auto_retrain_$(date +%Y%m%d_%H%M%S).log"
MATCHED_DIR="/data/weather_output/retrospective"
CHECKPOINT_DIR="/data/weather_output/transformer_models"
STATE_FILE="${CHECKPOINT_DIR}/last_retrain_state.txt"

# Минимальное количество НОВЫХ matched дат для запуска переобучения
NEW_DATES_THRESHOLD=3

mkdir -p "$LOG_DIR" "$CHECKPOINT_DIR"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG"; }

log ""
log "АВТО-ПЕРЕОБУЧЕНИЕ ТРАНСФОРМЕРА"
log ""


# ШАГ 1: Скачать новые факт данные с SFTP

log ""
log "ШАГ 1/4: Скачивание новых факт данных с SFTP"
"${SCRIPTS_DIR}/sftp_download_fact.sh" 2>&1 | tee -a "$LOG"
log "ШАГ 1 завершён"


# ШАГ 2: Конвертировать xlsx → observations CSV

log ""
log "ШАГ 2/4: Конвертация xlsx → observations CSV"
python3 "${SCRIPTS_DIR}/convert_fact_xlsx_to_obs.py" 2>&1 | tee -a "$LOG"
log "ШАГ 2 завершён"


# ШАГ 3: Матчинг новых наблюдений с WRF прогнозами

log ""
log "ШАГ 3/4: Матчинг наблюдений с WRF прогнозами"
NEW_MATCHED=$(python3 "${SCRIPTS_DIR}/match_wrf_with_fact_obs.py" 2>&1 | tee -a "$LOG" | grep "Создано новых matched файлов:" | grep -oE '[0-9]+$' || echo "0")
log "ШАГ 3 завершён: создано новых matched файлов: ${NEW_MATCHED}"


# ШАГ 4: Переобучение если достаточно новых данных

log ""
log "ШАГ 4/4: Проверка необходимости переобучения"

TOTAL_MATCHED=$(ls "${MATCHED_DIR}"/matched_forecast_obs_????????.csv 2>/dev/null | wc -l)
log "Всего matched дат: ${TOTAL_MATCHED}"

# Читаем сколько дат было при последнем обучении
LAST_TOTAL=0
if [ -f "$STATE_FILE" ]; then
    LAST_TOTAL=$(cat "$STATE_FILE" | grep "matched_dates=" | cut -d= -f2 || echo "0")
fi

DELTA=$((TOTAL_MATCHED - LAST_TOTAL))
log "При последнем обучении: ${LAST_TOTAL} дат | Новых: ${DELTA}"

if [ "$DELTA" -lt "$NEW_DATES_THRESHOLD" ]; then
    log "Недостаточно новых дат (${DELTA} < ${NEW_DATES_THRESHOLD}). Переобучение пропускается."
    log ""
    log ""
    log "Готово (без переобучения)"
    log ""
    exit 0
fi

log "Достаточно новых дат (${DELTA} >= ${NEW_DATES_THRESHOLD}). Запускаем переобучение..."
log ""

RETRAIN_LOG="${LOG_DIR}/retrain_$(date +%Y%m%d_%H%M%S).log"
log "Лог обучения: ${RETRAIN_LOG}"


# BACKUP: сохраняем текущие модели перед переобучением (для отката).
# Ротация: храним 4 последних бэкапа (≈1 месяц при еженедельных переобучениях).

BACKUP_DIR="${CHECKPOINT_DIR}/backup_$(date -u +%Y%m%d_%H%M%S)"
log ""
log "BACKUP: сохраняем текущие модели в ${BACKUP_DIR}"
mkdir -p "$BACKUP_DIR"
if [ -f "${CHECKPOINT_DIR}/best_model.pt" ]; then
    cp "${CHECKPOINT_DIR}/best_model.pt" "${BACKUP_DIR}/" || true
fi
if [ -d "${CHECKPOINT_DIR}/ensemble" ]; then
    cp -r "${CHECKPOINT_DIR}/ensemble" "${BACKUP_DIR}/" || true
fi
if [ -f "/data/weather_output/ml/xgboost_bias_correction.pkl" ]; then
    cp "/data/weather_output/ml/xgboost_bias_correction.pkl" "${BACKUP_DIR}/" || true
fi
# Ротация: держим только 4 последних бэкапа
ls -1dt "${CHECKPOINT_DIR}"/backup_* 2>/dev/null | tail -n +5 | xargs -r rm -rf
log "BACKUP готов (оставлено $(ls -1d "${CHECKPOINT_DIR}"/backup_* 2>/dev/null | wc -l) бэкапов)"


# ШАГ 4a: XGBoost - переобучение на всех matched датах

log ""
log "ШАГ 4a/4: Переобучение XGBoost"

XGB_ACCEPTED=0  # 1 = XGB прошёл gap-check и НЕ откатывается при провале Transformer

python3 "${SCRIPTS_DIR}/train_xgboost_bias.py" 2>&1 | tee -a "$RETRAIN_LOG" "$LOG"
XGB_EXIT=${PIPESTATUS[0]}

if [ $XGB_EXIT -eq 0 ]; then
    log " XGBoost переобучен"
    # Gap-check: max training_date в pkl не должен отставать от последнего matched >14 дней
    set +e
    XGB_GAP=$(python3 - <<'PY' 2>/dev/null
import pickle, glob, os, sys
from datetime import datetime
PKL   = "/data/weather_output/ml/xgboost_bias_correction.pkl"
RETRO = "/data/weather_output/retrospective"
try:
    data = pickle.load(open(PKL, "rb"))
    max_t = str(max(data["training_dates"]))
    files = sorted(glob.glob(os.path.join(RETRO, "matched_forecast_obs_????????.csv")))
    latest = os.path.basename(files[-1])[-12:-4]
    gap = (datetime.strptime(latest, "%Y%m%d") - datetime.strptime(max_t, "%Y%m%d")).days
    print(gap)
except Exception:
    print(999)
PY
)
    set -e
    XGB_GAP=${XGB_GAP:-999}
    if [ "$XGB_GAP" -le 14 ]; then
        XGB_ACCEPTED=1
        log " XGB gap-check OK (gap=${XGB_GAP}d ≤ 14d) - при провале Transformer откат XGB не делается"
    else
        log "  XGB stale (gap=${XGB_GAP}d > 14d) - XGB будет откачен при общем rollback"
    fi
else
    log "  XGBoost завершился с ошибкой (exit code: ${XGB_EXIT}), продолжаем с трансформером"
fi


# ШАГ 4b: Transformer - дообучение от чекпоинта

log ""
log "ШАГ 4b/4: Дообучение трансформера"

BEST_MODEL="${CHECKPOINT_DIR}/best_model.pt"

# В первое воскресенье месяца (1-7 число) - full retrain с нуля + пересборка ансамбля.
# Это нужно, чтобы скейлер и веса согласовались с текущим распределением данных
# и модель не "застревала" на зимнем режиме при сезонной смене.
DOM=$(date +%-d)
FIRST_SUNDAY_OF_MONTH=0
if [ "$DOM" -le 7 ]; then
    FIRST_SUNDAY_OF_MONTH=1
fi

# Кроме того: если новых дат > 5 (сильное расширение распределения) -
# обнуляем best_val_loss, чтобы свежая модель могла стать лучшей.
RESET_BEST_ARG=""
if [ "$DELTA" -gt 5 ]; then
    RESET_BEST_ARG="--reset-best-loss"
    log "Δ=${DELTA} > 5: добавлен --reset-best-loss"
fi

if [ "$FIRST_SUNDAY_OF_MONTH" -eq 1 ]; then
    log "Первое воскресенье месяца (day=${DOM}) → FULL RETRAIN с нуля"
    RESUME_ARG=""
    RESET_BEST_ARG=""  # с нуля и так, флаг не нужен
elif [ -f "$BEST_MODEL" ]; then
    log "Дообучение от чекпоинта: ${BEST_MODEL}"
    RESUME_ARG="--resume ${BEST_MODEL}"
else
    log "Чекпоинт не найден - обучение с нуля"
    RESUME_ARG=""
fi

NCCL_NVLS_ENABLE=0 torchrun \
    --nproc_per_node=8 \
    "${SCRIPTS_DIR}/transformer/train.py" \
    --config "${SCRIPTS_DIR}/transformer/config.yaml" \
    ${RESUME_ARG} \
    ${RESET_BEST_ARG} \
    2>&1 | tee -a "$RETRAIN_LOG" "$LOG"

TRAIN_EXIT=${PIPESTATUS[0]}

# Ансамбль:
#   - Первое воскресенье месяца → FULL rebuild всех 8 членов с нуля
#   - Остальные воскресенья → partial retrain 2 худших членов (по val_loss)
ENSEMBLE_EXIT=0
ENSEMBLE_DIR="${CHECKPOINT_DIR}/ensemble"
if [ $TRAIN_EXIT -eq 0 ]; then
    if [ "$FIRST_SUNDAY_OF_MONTH" -eq 1 ]; then
        log ""
        log "ШАГ 4c/4: FULL RETRAIN ансамбля (первое воскресенье месяца)"
        NCCL_NVLS_ENABLE=0 python3 "${SCRIPTS_DIR}/transformer/train_ensemble.py" \
            --config "${SCRIPTS_DIR}/transformer/config.yaml" \
            2>&1 | tee -a "$RETRAIN_LOG" "$LOG"
        ENSEMBLE_EXIT=${PIPESTATUS[0]}
    else
        log ""
        log "ШАГ 4c/4: PARTIAL retrain ансамбля (2 худших по val_loss)"

        WORST=$(python3 - "$ENSEMBLE_DIR" <<'PY'
import glob, os, sys, torch
ensemble_dir = sys.argv[1]
paths = sorted(glob.glob(os.path.join(ensemble_dir, "model_*.pt")))
vls = []
for p in paths:
    try:
        ck = torch.load(p, map_location="cpu", weights_only=False)
        idx = int(os.path.basename(p).split("_")[-1].split(".")[0])
        vls.append((idx, float(ck.get("val_loss", 1e9))))
    except Exception:
        idx = int(os.path.basename(p).split("_")[-1].split(".")[0])
        vls.append((idx, 1e9))
vls.sort(key=lambda x: -x[1])
print(",".join(str(i) for i, _ in vls[:2]))
PY
)

        if [ -z "$WORST" ]; then
            log "  Не удалось определить худших членов - пропускаем partial retrain"
            ENSEMBLE_EXIT=0
        else
            log "Худшие члены: ${WORST}"
            NCCL_NVLS_ENABLE=0 python3 "${SCRIPTS_DIR}/transformer/train_ensemble.py" \
                --config "${SCRIPTS_DIR}/transformer/config.yaml" \
                --only-members "$WORST" \
                2>&1 | tee -a "$RETRAIN_LOG" "$LOG"
            ENSEMBLE_EXIT=${PIPESTATUS[0]}
        fi
    fi

    if [ $ENSEMBLE_EXIT -eq 0 ]; then
        log " Ансамбль обновлён"
    else
        log "  Ансамбль завершился с ошибкой (exit=${ENSEMBLE_EXIT}) - продакшен использует старый"
    fi
fi


# ШАГ 5: Верификация свежеобученных моделей + откат при провале

if [ $TRAIN_EXIT -eq 0 ]; then
    log ""
    log "ШАГ 5/5: Верификация на последних matched датах"
    set +e
    VERIFY_OUT=$(python3 "${SCRIPTS_DIR}/verify_retrain.py" 2>&1)
    VERIFY_EXIT=$?
    set -e
    echo "$VERIFY_OUT" | tee -a "$RETRAIN_LOG" "$LOG" > /dev/null
    log "verify_retrain.py exit=${VERIFY_EXIT}"

    VERIFY_FIRST_LINE=$(echo "$VERIFY_OUT" | head -n1)

    if [ $VERIFY_EXIT -ne 0 ] || ! echo "$VERIFY_FIRST_LINE" | grep -q "^PASS"; then
        log " Верификация не пройдена: ${VERIFY_FIRST_LINE}"
        log "Выполняем откат из ${BACKUP_DIR}"

        if [ -f "${BACKUP_DIR}/best_model.pt" ]; then
            cp "${BACKUP_DIR}/best_model.pt" "${CHECKPOINT_DIR}/best_model.pt"
            log "   best_model.pt восстановлен"
        fi
        if [ -d "${BACKUP_DIR}/ensemble" ]; then
            rm -f "${CHECKPOINT_DIR}/ensemble"/*.pt 2>/dev/null || true
            cp "${BACKUP_DIR}/ensemble"/*.pt "${CHECKPOINT_DIR}/ensemble/" 2>/dev/null || true
            log "   ensemble/* восстановлен"
        fi
        if [ "$XGB_ACCEPTED" -ne 1 ] && [ -f "${BACKUP_DIR}/xgboost_bias_correction.pkl" ]; then
            cp "${BACKUP_DIR}/xgboost_bias_correction.pkl" "/data/weather_output/ml/xgboost_bias_correction.pkl"
            log "   xgboost_bias_correction.pkl восстановлен (XGB_ACCEPTED=0)"
        else
            log "  - xgboost_bias_correction.pkl НЕ откатываем (XGB_ACCEPTED=1)"
        fi

        if [ -f "${SCRIPTS_DIR}/telegram_notify.py" ]; then
            python3 "${SCRIPTS_DIR}/telegram_notify.py" \
                " *RETRAIN ROLLBACK*

    Дата: $(date '+%Y-%m-%d')
Верификация не пройдена, модели откачены.
\`${VERIFY_FIRST_LINE}\`
    Лог: \`$(basename $RETRAIN_LOG)\`" &
        fi
        exit 1
    fi
    log " Верификация пройдена: ${VERIFY_FIRST_LINE}"
fi

if [ $TRAIN_EXIT -eq 0 ]; then
    log ""
    log " Переобучение завершено успешно"

    # Сохраняем состояние
    cat > "$STATE_FILE" <<EOF
matched_dates=${TOTAL_MATCHED}
retrain_date=$(date '+%Y-%m-%d %H:%M:%S')
retrain_log=${RETRAIN_LOG}
xgb_exit=${XGB_EXIT}
EOF
    log "Состояние сохранено: ${STATE_FILE}"

    # Telegram уведомление
    if [ -f "${SCRIPTS_DIR}/telegram_notify.py" ]; then
        python3 "${SCRIPTS_DIR}/telegram_notify.py" \
            " *Авто-переобучение завершено*

    Дата: $(date '+%Y-%m-%d')
    Matched дат в обучении: ${TOTAL_MATCHED}
    Новых дат добавлено: ${DELTA}
    XGBoost: $([ $XGB_EXIT -eq 0 ] && echo 'OK' || echo 'ОШИБКА')
    Лог: \`$(basename $RETRAIN_LOG)\`" &
    fi
else
    log ""
    log " Трансформер завершился с ошибкой (exit code: ${TRAIN_EXIT})"

    if [ -f "${SCRIPTS_DIR}/telegram_notify.py" ]; then
        python3 "${SCRIPTS_DIR}/telegram_notify.py" \
            " *Авто-переобучение ОШИБКА (Transformer)*

    Дата: $(date '+%Y-%m-%d')
    XGBoost: $([ $XGB_EXIT -eq 0 ] && echo 'OK' || echo 'ОШИБКА')
Exit code: ${TRAIN_EXIT}
    Лог: \`$(basename $RETRAIN_LOG)\`" &
    fi
    exit 1
fi

log ""
log ""
log "АВТО-ПЕРЕОБУЧЕНИЕ ЗАВЕРШЕНО"
log "Log: ${LOG}"
log ""
