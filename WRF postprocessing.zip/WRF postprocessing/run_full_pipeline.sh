#!/bin/bash
# ПОЛНЫЙ PIPELINE С TELEGRAM УВЕДОМЛЕНИЯМИ

DATE=$1
HOUR="00"

if [ -z "$DATE" ]; then
    echo "Использование: $0 YYYYMMDD"
    exit 1
fi

# Функция отправки уведомлений
notify() {
    python3 /home/admin-kazgydromet/ml_scripts/telegram_notify.py "$1"
}

notify " *Старт прогноза на $DATE*"

echo ""
echo "ПОЛНЫЙ PIPELINE ПРОГНОЗА ПОГОДЫ"
echo ""
echo "Дата: $DATE"
echo "Старт: $(date)"
echo ""

#  Pre-flight: проверка свободного места 
# WRF + GFS + промежуточные файлы требуют ~120GB
MIN_FREE_GB=${MIN_FREE_GB:-120}
FREE_GB=$(df -BG /data | awk 'NR==2 {gsub("G",""); print $4}')
echo "Свободно на /data: ${FREE_GB}GB (требуется минимум ${MIN_FREE_GB}GB)"
if [ "${FREE_GB:-0}" -lt "$MIN_FREE_GB" ]; then
    notify " *МАЛО МЕСТА* на /data: ${FREE_GB}GB <${MIN_FREE_GB}GB. Запускаю cleanup."
    /data/scripts/cleanup_wrf_data.sh || true
    FREE_GB=$(df -BG /data | awk 'NR==2 {gsub("G",""); print $4}')
    if [ "${FREE_GB:-0}" -lt "$MIN_FREE_GB" ]; then
        notify " *АВАРИЯ*: после cleanup всё ещё ${FREE_GB}GB. Pipeline остановлен."
        exit 1
    fi
fi

WRF_BASE="/data/weather_models/wrf"
GFS_DIR="/data/weather_data/gfs/raw/${DATE}${HOUR}_extended"
OUTPUT_DIR="/data/weather_output/operational"

# Дата выходных файлов = дата запуска + 1 день (пропускаем первые 24ч WRF)
DATE_PLUS1=$(date -d "$DATE + 1 day" +%Y%m%d)

export NETCDF=/data/weather_models/wrf/netcdf
export HDF5=/data/weather_models/wrf/hdf5
export JASPERLIB=/data/weather_models/wrf/jasper/lib
export JASPERINC=/data/weather_models/wrf/jasper/include
export LD_LIBRARY_PATH=$NETCDF/lib:$HDF5/lib:$JASPERLIB:$LD_LIBRARY_PATH

mkdir -p $OUTPUT_DIR

#  ШАГ 1: GFS 
echo ""
echo "ШАГ 1/6: СКАЧИВАНИЕ GFS"
echo ""

gfs_count() { ls "$GFS_DIR"/gfs.* 2>/dev/null | wc -l; }

if [ -d "$GFS_DIR" ] && [ "$(gfs_count)" -eq 81 ]; then
    echo " GFS данные уже есть"
    notify " *GFS* данные найдены"
else
    notify " *Скачивание GFS* данных..."
    ~/ml_scripts/download_gfs_aws.sh $DATE $HOUR

    # Если докачать всё не удалось — подождать и попробовать ещё дважды
    # Защита на случай временной недоступности AWS / зависания download
    GFS_OUTER_RETRIES=${GFS_OUTER_RETRIES:-2}
    attempt=1
    while [ "$(gfs_count)" -lt 81 ] && [ $attempt -le $GFS_OUTER_RETRIES ]; do
        MISSING_COUNT=$((81 - $(gfs_count)))
        echo "  GFS не полный ($MISSING_COUNT файлов не хватает) — повтор $attempt/$GFS_OUTER_RETRIES через 120с"
        notify " *GFS* не полный, повтор $attempt/$GFS_OUTER_RETRIES"
        sleep 120
        ~/ml_scripts/download_gfs_aws.sh $DATE $HOUR
        attempt=$((attempt + 1))
    done

    if [ "$(gfs_count)" -lt 81 ]; then
        MISSING_COUNT=$((81 - $(gfs_count)))
        notify " *ОШИБКА* скачивания GFS — не хватает $MISSING_COUNT из 81 файлов после $GFS_OUTER_RETRIES повторов"
        exit 1
    fi
    notify " *GFS* скачан (81 файл)"
fi

echo ""

#  ШАГ 2: WRF 
echo ""
echo "ШАГ 2/6: РАСЧЁТ WRF"
echo ""

notify " *Запуск WRF* (~4 часа)..."

WRF_ATTEMPTS=${WRF_ATTEMPTS:-2}
wrf_attempt=1
while true; do
    ~/ml_scripts/run_single_retro_wrf.sh $DATE
    WRF_RC=$?
    if [ $WRF_RC -eq 0 ]; then
        break
    fi
    if [ $wrf_attempt -ge $WRF_ATTEMPTS ]; then
        notify " *ОШИБКА WRF* после $WRF_ATTEMPTS попыток (rc=$WRF_RC)"
        exit 1
    fi
    notify " *WRF упал* (rc=$WRF_RC) — повтор $wrf_attempt/$WRF_ATTEMPTS через 60с"
    sleep 60
    wrf_attempt=$((wrf_attempt + 1))
done

notify "*WRF завершён*"
echo ""

# ШАГ 3: POST-PROCESSING (XGBoost + Transformer) 
echo ""
echo "ШАГ 3/6: POST-PROCESSING"
echo ""

notify " *Применение ML* коррекции (XGBoost + Transformer)..."

WRF_CSV="/data/weather_output/retrospective/wrf_forecast_${DATE}.csv"

if [ ! -f "$WRF_CSV" ]; then
    notify " *Нет файла* прогноза"
    exit 1
fi

PP_ATTEMPTS=${PP_ATTEMPTS:-2}
pp_attempt=1
PP_RC=1
while [ $pp_attempt -le $PP_ATTEMPTS ]; do
    python3 /data/scripts/run_operational_postprocess.py "$DATE"
    PP_RC=$?
    if [ $PP_RC -eq 0 ]; then
        break
    fi
    if [ $pp_attempt -lt $PP_ATTEMPTS ]; then
        notify " *Post-Processing упал* (rc=$PP_RC) — повтор $pp_attempt/$PP_ATTEMPTS через 30с"
        sleep 30
    fi
    pp_attempt=$((pp_attempt + 1))
done

if [ $PP_RC -eq 0 ]; then
    FILE_SIZE=$(du -h "$OUTPUT_DIR/forecast_${DATE_PLUS1}_final.xlsx" 2>/dev/null | cut -f1)
    RECORDS=$(wc -l < "$OUTPUT_DIR/forecast_${DATE_PLUS1}_final.csv" 2>/dev/null)
    notify " *Post-Processing готов* ($RECORDS записей, $FILE_SIZE)"
else
    notify " *ОШИБКА* Post-Processing после $PP_ATTEMPTS попыток"
    exit 1
fi

echo ""

#  ШАГ 4: ВИЗУАЛИЗАЦИЯ 
echo ""
echo "ШАГ 4/6: ВИЗУАЛИЗАЦИЯ (NCL КАРТЫ)"
echo ""

notify " *Визуализация* карт..."

WRF_RUN_DIR="$WRF_BASE/WRF/test/em_real_retro_${DATE}_v2"
/data/scripts/visualization/run_visualization.sh "$WRF_RUN_DIR" "$DATE_PLUS1"

if [ $? -eq 0 ]; then
    notify " *PIPELINE ЗАВЕРШЁН!*

    Прогноз на: $DATE_PLUS1
    Записей: $RECORDS
    Размер: $FILE_SIZE
    \`forecast_${DATE_PLUS1}_final.xlsx\`
    Карты: \`/data/weather_output/images/\`

WRF + ML коррекция + NCL карты
    Завершено: $(date +%H:%M)"
else
    notify " *PIPELINE ГОТОВ* (визуализация с ошибками)
    Завершено: $(date +%H:%M)"
fi

echo ""

#  ШАГ 4.5: ГЕНЕРАЦИЯ ВЕБ-ДАШБОРДА 
echo ""
echo "ШАГ 4.5/6: ГЕНЕРАЦИЯ ВЕБ-ДАШБОРДА"
echo ""

notify " *Генерация веб-дашборда*..."
/data/scripts/visualization/generate_web_dashboard.sh "$DATE"
WEB_RC=$?

if [ $WEB_RC -ne 0 ]; then
    notify " *Веб-дашборд* не обновлён (пайплайн продолжается)"
fi

echo ""

#  ШАГ 5: SFTP UPLOAD 
echo ""
echo "ШАГ 5/6: SFTP UPLOAD (PNG/XLSX)"
echo ""

SFTP_DATE=$(date -d "$DATE_PLUS1" '+%d.%m.%Y')
SFTP_DATE="$SFTP_DATE" WRF_DIR="$WRF_RUN_DIR" /data/scripts/sftp_upload.sh

echo ""

#  ШАГ 6: SFTP UPLOAD ДАШБОРДА 
echo ""
echo "ШАГ 6/6: SFTP UPLOAD ДАШБОРДА"
echo ""

if [ $WEB_RC -eq 0 ]; then
    /data/scripts/sftp_upload_dashboard.sh
else
    echo "Пропуск: генерация веб-дашборда упала на ШАГ 4.5"
    notify "⏭ *Dashboard SFTP пропущен* (ШАГ 4.5 упал)"
fi

echo ""

#  ШАГ 7: JSON API EXPORT + SFTP 
echo ""
echo "ШАГ 7: JSON API EXPORT + SFTP"
echo ""

notify "📡 *Экспорт JSON API*..."
# Обогащение CSV полями RH/dew/CAPE/cloud (опционально, не блокирует)
python3 /data/scripts/enrich_forecast_extras.py "$DATE_PLUS1" "$WRF_RUN_DIR" \
    || notify " *Enrich CSV* упал (JSON будет без humidity/cape)"
python3 /data/scripts/export_forecast_json.py "$DATE_PLUS1"
if [ $? -eq 0 ]; then
    /data/scripts/sftp_upload_api.sh "$DATE_PLUS1"
else
    notify " *JSON API* экспорт упал (SFTP пропущен)"
fi

echo ""
echo ""
echo "PIPELINE ЗАВЕРШЁН!"
echo ""

