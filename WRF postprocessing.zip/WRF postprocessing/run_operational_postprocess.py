#!/usr/bin/env python3
"""
Оперативный post-processing: XGBoost + Transformer коррекция WRF прогноза.
Без наблюдений - только улучшение прогноза.

Использование:
  python3 run_operational_postprocess.py YYYYMMDD
"""

import sys
import os
import glob
import pickle
import logging

import numpy as np
import pandas as pd
import torch
import yaml

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

logging.basicConfig(level=logging.INFO, format="[%(asctime)s] %(message)s", datefmt="%H:%M:%S")
logger = logging.getLogger(__name__)

# Пути 
RETRO_DIR    = "/data/weather_output/retrospective"
OUT_DIR      = "/data/weather_output/operational"
XGB_PATH     = "/data/weather_output/ml/xgboost_bias_correction.pkl"
MODEL_PATH   = "/data/weather_output/transformer_models/best_model.pt"
ENSEMBLE_DIR = "/data/weather_output/transformer_models/ensemble"
CONFIG_PATH  = "/data/scripts/transformer/config.yaml"
STATIONS_CSV = "/data/stations/all_stations.csv"
STATIONS_INFO = "/data/weather_data/observations/stations_info.csv"
WRF_DIR      = "/data/weather_models/wrf/WRF/test/em_real"
VIRTUAL_GRID_STEP = 9   # каждые 9 ячеек ≈ 54 км

HEADER_FILL  = PatternFill("solid", fgColor="366092")
HEADER_FONT  = Font(bold=True, color="FFFFFF", size=11)
HEADER_ALIGN = Alignment(horizontal="center", vertical="center", wrap_text=True)
ALT_FILL     = PatternFill("solid", fgColor="DCE6F1")
CELL_BORDER  = Border(bottom=Side(style="thin", color="B8CCE4"))


def main():
    if len(sys.argv) < 2:
        print("Использование: python3 run_operational_postprocess.py YYYYMMDD")
        sys.exit(1)

    date_str = sys.argv[1]
    wrf_csv  = f"{RETRO_DIR}/wrf_forecast_{date_str}.csv"

    if not os.path.exists(wrf_csv):
        logger.error(f"Файл не найден: {wrf_csv}")
        sys.exit(1)

    # Дата выходного файла = дата запуска + 1 день (пропускаем первые 24ч WRF)
    from datetime import datetime, timedelta
    run_dt   = datetime.strptime(date_str, "%Y%m%d")
    next_dt  = run_dt + timedelta(days=1)
    out_date = next_dt.strftime("%Y%m%d")
    logger.info(f"Post-processing для {date_str} → выходной файл: {out_date}")

    # Загрузка WRF прогноза
    df = pd.read_csv(wrf_csv)
    df["datetime"] = pd.to_datetime(df["forecast_date"].str.replace("_", " "))

    # Добавляем метаданные станций
    if os.path.exists(STATIONS_INFO):
        st = pd.read_csv(STATIONS_INFO)
        df = df.merge(st[["id", "name", "lat", "lon"]], left_on="rep_id", right_on="id", how="left")
    elif os.path.exists(STATIONS_CSV):
        st = pd.read_csv(STATIONS_CSV)
        df = df.merge(st[["IndexNbr", "lat", "lon"]].rename(columns={"IndexNbr": "id"}),
                      left_on="rep_id", right_on="id", how="left")

    logger.info(f"WRF: {len(df):,} строк, {df['rep_id'].nunique()} станций")

    # Пропускаем первые 24 часа - берём только с 00:00 следующего дня 
    cutoff = pd.Timestamp(next_dt.strftime("%Y-%m-%d"))
    df = df[df["datetime"] >= cutoff].copy()
    logger.info(f"После фильтра (>= {cutoff.date()}): {len(df):,} строк")

    # Накопительные осадки → почасовые 
    if "rain_stn" in df.columns:
        df = df.sort_values(["rep_id", "datetime"]).copy()
        hourly_rain = df.groupby("rep_id")["rain_stn"].diff().clip(lower=0)
        df["rain_stn"] = hourly_rain.fillna(df["rain_stn"])

    # XGBoost 
    if os.path.exists(XGB_PATH):
        with open(XGB_PATH, "rb") as f:
            xgb_data = pickle.load(f)
        xgb_model    = xgb_data["model"]
        xgb_features = xgb_data["feature_cols"]

        init_dt = pd.Timestamp(f"{date_str[:4]}-{date_str[4:6]}-{date_str[6:8]} 00:00:00")
        df["forecast_hour"] = (df["datetime"] - init_dt).dt.total_seconds() / 3600
        h     = df["datetime"].dt.hour
        doy   = df["datetime"].dt.dayofyear
        month = df["datetime"].dt.month
        df["hour_sin"]  = np.sin(2 * np.pi * h / 24)
        df["hour_cos"]  = np.cos(2 * np.pi * h / 24)
        df["day_sin"]   = np.sin(2 * np.pi * doy / 365)
        df["day_cos"]   = np.cos(2 * np.pi * doy / 365)
        df["month_sin"] = np.sin(2 * np.pi * month / 12)
        df["month_cos"] = np.cos(2 * np.pi * month / 12)

        # Polynomial forecast horizon (WRF error grows nonlinearly)
        df["forecast_hour_sq"]  = df["forecast_hour"] ** 2
        df["forecast_hour_cub"] = df["forecast_hour"] ** 3

        # Wind features (derived from components)
        df["wind_speed"] = np.sqrt(df["windU_stn"]**2 + df["windV_stn"]**2)
        spd = df["wind_speed"].replace(0, np.nan)
        df["wind_dir_sin"] = (df["windU_stn"] / spd).fillna(0.0)
        df["wind_dir_cos"] = (df["windV_stn"] / spd).fillna(0.0)

        # Temporal trends (single forecast date - group by station only)
        df = df.sort_values(["rep_id", "datetime"])
        df["temp_trend"]        = df.groupby("rep_id")["temp_stn"].diff().fillna(0.0)
        df["pressure_tendency"] = df.groupby("rep_id")["pressure_stn"].diff().fillna(0.0)

        # Lagged features (previous 3h step, fillna with current value at first step)
        df["temp_stn_lag3h"]     = df.groupby("rep_id")["temp_stn"].shift(1).fillna(df["temp_stn"])
        df["pressure_stn_lag3h"] = df.groupby("rep_id")["pressure_stn"].shift(1).fillna(df["pressure_stn"])

        # Interactions
        df["temp_x_fhour"] = df["temp_stn"] * df["forecast_hour"]
        df["ptend_x_wind"] = df["pressure_tendency"] * df["wind_speed"]

        # Elevation proxy from surface pressure
        df["elevation_proxy"] = -8000.0 * np.log(df["pressure_stn"] / 1013.25)

        # Station mean bias (stored in model pickle at training time)
        stn_bias_dict = xgb_data.get("station_mean_bias", {})
        global_bias   = xgb_data.get("global_mean_bias", 0.0)
        df["mean_bias_station"] = df["rep_id"].map(stn_bias_dict).fillna(global_bias)

        # Клип признаков к train-перцентилям [1, 99] - подавляет экстраполяцию
        # на дальних сроках прогноза (иначе XGB даёт −5°C коррекции на +10 день).
        feat_pct = xgb_data.get("feature_percentiles", {})
        for col in xgb_features:
            if col in feat_pct:
                lo, hi = feat_pct[col]
                df[col] = df[col].clip(lower=lo, upper=hi)

        X = df[xgb_features].fillna(0).values
        pred_err = xgb_model.predict(X)
        # Дополнительный клип самой коррекции к разумному диапазону ±8°C.
        pred_err = np.clip(pred_err, -8.0, 8.0)
        df["temp_xgb"]        = df["temp_stn"].values - pred_err
        df["correction_xgb"]  = -pred_err
        logger.info(f"XGBoost применён. Средняя коррекция: {-pred_err.mean():+.2f}°C "
                    f"(клипы: перцентили={len(feat_pct)>0}, err=±8°C)")
    else:
        logger.warning(f"XGBoost модель не найдена: {XGB_PATH}")
        df["temp_xgb"]       = df["temp_stn"]
        df["correction_xgb"] = 0.0

    # Transformer / Ансамбль 
    sys.path.insert(0, "/data/scripts/transformer")
    ensemble_models = sorted(glob.glob(os.path.join(ENSEMBLE_DIR, "model_*.pt")))
    use_ensemble = len(ensemble_models) > 0

    try:
        if use_ensemble:
            from apply_ensemble import ensemble_predict
            logger.info(f"Ансамбль: {len(ensemble_models)} моделей из {ENSEMBLE_DIR}")
            ml_df = ensemble_predict(wrf_csv, STATIONS_CSV, ENSEMBLE_DIR, CONFIG_PATH)
            if ml_df is not None:
                df = df.merge(ml_df, on=["rep_id", "datetime"], how="left")
                df["correction_ml"] = df["temp_ml"] - df["temp_stn"]
                logger.info(
                    f"Ансамбль применён. Средняя неопределённость: "
                    f"{df['temp_ml_std'].mean():.2f}°C"
                )
            else:
                raise RuntimeError("ensemble_predict вернул None")
        else:
            from apply_transformer import load_model_and_scaler, load_forecast_csv

            with open(CONFIG_PATH) as f:
                cfg = yaml.safe_load(f)

            device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
            model, scaler, ckpt = load_model_and_scaler(MODEL_PATH, cfg, device)
            logger.info(f"Transformer: epoch {ckpt.get('epoch','?')}, val_loss {ckpt.get('val_loss',0):.4f}")

            _tmp = pd.read_csv(wrf_csv)
            actual_stations = max(cfg["data"]["max_stations"], _tmp["rep_id"].nunique())
            data = load_forecast_csv(wrf_csv, stations_csv=STATIONS_CSV,
                                     input_cols=cfg["data"]["input_cols"],
                                     max_stations=actual_stations, scaler=scaler)

            n_real = data["n_real_stations"]
            with torch.no_grad(), torch.amp.autocast("cuda", enabled=device.type=="cuda", dtype=torch.bfloat16):
                pred = model(data["wrf_features"].to(device),
                             data["station_coords"].to(device),
                             data["station_mask"].to(device),
                             data["forecast_hours"].to(device))

            pred_np  = pred[0, :n_real, :, 0].cpu().float().numpy()
            stations = data["stations_in_file"][:n_real]
            hours_np = data["hours_arr"]
            init_dt  = data["init_dt"]

            ml_rows = []
            for si, rep_id in enumerate(stations):
                for ti, fh in enumerate(hours_np):
                    dt = init_dt + pd.Timedelta(hours=float(fh))
                    ml_rows.append({"rep_id": int(rep_id), "datetime": dt,
                                     "temp_ml": round(float(pred_np[si, ti]), 2)})

            ml_df = pd.DataFrame(ml_rows)
            df = df.merge(ml_df, on=["rep_id", "datetime"], how="left")
            df["correction_ml"] = df["temp_ml"] - df["temp_stn"]
            logger.info("Transformer применён (одиночная модель)")

    except Exception as e:
        logger.warning(f"Transformer пропущен: {e}")
        df["temp_ml"]       = df["temp_stn"]
        df["correction_ml"] = 0.0
        df["temp_ml_std"]   = 0.0

    # Сохранение CSV
    os.makedirs(OUT_DIR, exist_ok=True)
    csv_out = f"{OUT_DIR}/forecast_{out_date}_final.csv"

    df["wind_speed"] = 1.3 * np.sqrt(df["windU_stn"]**2 + df["windV_stn"]**2)

    out_cols = ["rep_id", "forecast_date", "temp_stn", "temp_xgb", "temp_ml",
                "temp_ml_std", "correction_xgb", "correction_ml",
                "rain_stn", "wind_speed", "pressure_stn"]
    if "name" in df.columns:
        out_cols = ["rep_id", "name"] + out_cols[1:]

    df[[c for c in out_cols if c in df.columns]].to_csv(csv_out, index=False)
    logger.info(f"CSV: {csv_out}")

    # Форматированный XLSX
    xlsx_out = f"{OUT_DIR}/forecast_{out_date}_final.xlsx"
    _save_forecast_xlsx(df, xlsx_out, out_date)
    size_kb = os.path.getsize(xlsx_out) // 1024
    logger.info(f"XLSX: {xlsx_out} ({size_kb} KB)")
    logger.info(f"Готово: {df['rep_id'].nunique()} станций, {len(df):,} строк")

    # Виртуальная сетка по всему Казахстану
    ensemble_models = sorted(glob.glob(os.path.join(ENSEMBLE_DIR, "model_*.pt")))
    if ensemble_models:
        _run_virtual_grid(date_str, out_date)
    else:
        logger.info("Виртуальная сетка пропущена (ансамбль не обучен)")


def _run_virtual_grid(date_str: str, out_date: str):
    """Извлекает WRF на виртуальной сетке и прогоняет ансамбль."""
    import subprocess
    from scipy.interpolate import griddata
    from netCDF4 import Dataset as NC

    logger.info(" Виртуальная сетка ")

    virtual_csv = f"{RETRO_DIR}/wrf_virtual_grid_{date_str}.csv"

    # Шаг 1: извлечение из wrfout (если ещё нет)
    if not os.path.exists(virtual_csv):
        logger.info("Извлечение WRF на виртуальной сетке...")
        result = subprocess.run(
            ["python3", "/data/scripts/extract_virtual_grid.py",
             "--date", date_str,
             "--step", str(VIRTUAL_GRID_STEP),
             "--wrf-dir", WRF_DIR,
             "--output-dir", RETRO_DIR],
            capture_output=True, text=True
        )
        if result.returncode != 0:
            logger.warning(f"Ошибка извлечения сетки: {result.stderr[-500:]}")
            return
        logger.info(f"Виртуальная сетка извлечена: {virtual_csv}")
    else:
        logger.info(f"Виртуальная сетка уже есть: {virtual_csv}")

    # Шаг 2: прогон ансамбля по виртуальным точкам
    sys.path.insert(0, "/data/scripts/transformer")
    from apply_ensemble import ensemble_predict

    logger.info("Ансамбль на виртуальной сетке...")
    grid_df = ensemble_predict(virtual_csv, STATIONS_CSV, ENSEMBLE_DIR, CONFIG_PATH)
    if grid_df is None:
        logger.warning("Ансамбль не вернул результат для виртуальной сетки")
        return

    # Добавляем lat/lon из virtual_csv
    vst_meta = pd.read_csv(virtual_csv, usecols=["rep_id", "lat", "lon"]).drop_duplicates("rep_id")
    grid_df = grid_df.merge(vst_meta, on="rep_id", how="left")

    # Шаг 3: накопительные осадки → почасовые
    vraw = pd.read_csv(virtual_csv)
    vraw["datetime"] = pd.to_datetime(vraw["forecast_date"].str.replace("_", " "))
    from datetime import datetime, timedelta
    run_dt  = datetime.strptime(date_str, "%Y%m%d")
    next_dt = run_dt + timedelta(days=1)
    cutoff  = pd.Timestamp(next_dt.strftime("%Y-%m-%d"))
    vraw = vraw[vraw["datetime"] >= cutoff].copy()
    vraw = vraw.sort_values(["rep_id", "datetime"])
    vraw["rain_hourly"] = vraw.groupby("rep_id")["rain_stn"].diff().clip(lower=0)
    vraw["rain_hourly"] = vraw["rain_hourly"].fillna(vraw["rain_stn"])

    grid_df = grid_df.merge(
        vraw[["rep_id", "datetime", "temp_stn", "rain_hourly",
              "windU_stn", "windV_stn", "pressure_stn"]],
        on=["rep_id", "datetime"], how="left"
    )

    # Шаг 4: интерполяция коррекции на полную сетку WRF
    wrfout_files = sorted(glob.glob(f"{WRF_DIR}/wrfout_d01_*"))
    if wrfout_files:
        nc = NC(wrfout_files[0], "r")
        lats_full = nc.variables["XLAT"][0, :, :]
        lons_full = nc.variables["XLONG"][0, :, :]
        nc.close()

        # Берём среднюю коррекцию за весь период
        mean_corr = grid_df.groupby("rep_id").apply(
            lambda g: g["temp_ml"].mean() - g["temp_stn"].mean()
        ).reset_index(name="mean_correction")
        mean_corr = mean_corr.merge(vst_meta, on="rep_id", how="left")

        pts  = mean_corr[["lat", "lon"]].values
        vals = mean_corr["mean_correction"].values
        full_pts = np.column_stack([lats_full.ravel(), lons_full.ravel()])

        corr_field = griddata(pts, vals, full_pts, method="linear")
        corr_field = corr_field.reshape(lats_full.shape)

        # Сохраняем поле коррекций как npy для визуализации
        npy_out = f"{OUT_DIR}/correction_field_{out_date}.npy"
        np.save(npy_out, corr_field.astype(np.float32))
        logger.info(f"Поле коррекций (540×360): {npy_out}")

    # Шаг 5: сохранение виртуальной сетки как CSV
    grid_csv = f"{OUT_DIR}/virtual_grid_{out_date}_final.csv"
    grid_df.to_csv(grid_csv, index=False)
    logger.info(
        f"Виртуальная сетка: {grid_df['rep_id'].nunique()} точек → {grid_csv}"
    )
    logger.info(
        f"Средняя коррекция ансамбля: "
        f"{(grid_df['temp_ml'] - grid_df['temp_stn']).mean():+.2f}°C, "
        f"неопределённость: {grid_df['temp_ml_std'].mean():.2f}°C"
    )


def _save_forecast_xlsx(df: pd.DataFrame, path: str, date_str: str):
    COLUMNS = [
        ("forecast_date",  "Дата прогноза",        22, "@"),
        ("rep_id",         "ID станции",             9, "0"),
        ("name",           "Станция",               20, "@"),
        ("lat",            "Широта",                 9, "0.00"),
        ("lon",            "Долгота",                9, "0.00"),
        ("temp_stn",       "WRF_T (°C)",            10, "0.0"),
        ("temp_xgb",       "XGB_T (°C)",            10, "0.0"),
        ("temp_ml",        "Ансамбль_T (°C)",       16, "0.0"),
        ("temp_ml_std",    "Неопред. (°C)",          14, "0.00"),
        ("correction_xgb", "Коррекция XGB (°C)",    16, "0.00"),
        ("correction_ml",  "Коррекция Transf. (°C)",18, "0.00"),
        ("rain_stn",       "Осадки (мм)",           12, "0.00"),
        ("wind_speed",     "Скорость ветра (м/с)",  18, "0.0"),
        ("pressure_stn",   "Давление (гПа)",         14, "0.1"),
    ]

    present = [c[0] for c in COLUMNS if c[0] in df.columns]
    col_hdr = {c[0]: c[1] for c in COLUMNS}
    col_w   = {c[0]: c[2] for c in COLUMNS}
    col_fmt = {c[0]: c[3] for c in COLUMNS}

    wb = Workbook()
    ws = wb.active
    ws.title = "Прогноз"

    for ci, col in enumerate(present, 1):
        cell = ws.cell(1, ci, col_hdr[col])
        cell.font = HEADER_FONT; cell.fill = HEADER_FILL; cell.alignment = HEADER_ALIGN
        ws.column_dimensions[get_column_letter(ci)].width = col_w[col]
    ws.row_dimensions[1].height = 24

    for ri, (_, row) in enumerate(df[present].iterrows(), 2):
        fill = ALT_FILL if ri % 2 == 0 else None
        for ci, col in enumerate(present, 1):
            val = row[col]
            if isinstance(val, float) and np.isnan(val):
                val = ""
            cell = ws.cell(ri, ci, val)
            cell.number_format = col_fmt[col]
            cell.border = CELL_BORDER
            if fill:
                cell.fill = fill

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions

    # Лист 2: Сводка по станциям (средние за 10 дней)
    ws2 = wb.create_sheet("Сводка")
    sum_hdrs = [("Станция", 20), ("ID", 8), ("WRF_T ср.", 11),
                ("XGB_T ср.", 11), ("Transf_T ср.", 13),
                ("Коррекц. XGB", 13), ("Коррекц. Transf.", 15),
                ("Осадки сумм.", 12)]

    for ci, (h, w) in enumerate(sum_hdrs, 1):
        cell = ws2.cell(1, ci, h)
        cell.font = HEADER_FONT; cell.fill = HEADER_FILL; cell.alignment = HEADER_ALIGN
        ws2.column_dimensions[get_column_letter(ci)].width = w
    ws2.row_dimensions[1].height = 24

    grp = df.groupby(["rep_id", "name"] if "name" in df.columns else ["rep_id"])
    sum_rows = []
    for key, g in grp:
        rep_id, name = (key[0], key[1]) if isinstance(key, tuple) else (key, str(key))
        sum_rows.append([
            name, rep_id,
            round(g["temp_stn"].mean(), 1),
            round(g["temp_xgb"].mean(), 1) if "temp_xgb" in g.columns else "",
            round(g["temp_ml"].mean(), 1) if "temp_ml" in g.columns else "",
            round(g["correction_xgb"].mean(), 2) if "correction_xgb" in g.columns else "",
            round(g["correction_ml"].mean(), 2) if "correction_ml" in g.columns else "",
            round(g["rain_stn"].sum(), 1) if "rain_stn" in g.columns else "",
        ])

    sum_rows.sort(key=lambda r: str(r[0]))
    for ri, vals in enumerate(sum_rows, 2):
        fill = ALT_FILL if ri % 2 == 0 else None
        for ci, val in enumerate(vals, 1):
            cell = ws2.cell(ri, ci, val)
            cell.number_format = "0.0" if isinstance(val, float) else "General"
            cell.border = CELL_BORDER
            if fill:
                cell.fill = fill

    ws2.freeze_panes = "A2"

    wb.save(path)


if __name__ == "__main__":
    main()
