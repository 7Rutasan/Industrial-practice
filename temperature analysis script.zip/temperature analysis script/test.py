import os
import re
import glob
import difflib
import unicodedata
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from googletrans import Translator

translator = Translator()

plt.rcParams["font.family"] = "DejaVu Sans"
plt.rcParams["axes.unicode_minus"] = False

# 1. НАСТРОЙКИ
# Папки с исходными файлами
DATA_DIR = "data"
CADASTRE_DIR = "CADASTRE"

# Что искать:
# 1) Если список пустой -> обработаются ВСЕ города, которые найдены одновременно
#    и в data, и в CADASTRE.
# 2) Если список заполнен -> можно писать любые названия/варианты,
#    скрипт попробует сам подобрать совпадающую станцию.
CITY_QUERIES = [
    # "Петропавл",
    # "Тайынша",
    # "Кишкенеколь",
]

# Префикс папок результатов
RESULT_PREFIX = "temp_results"

# Допуск для нестрогого поиска похожих названий
FUZZY_CUTOFF = 0.72

month_names_ru = {
    1: "Январь",
    2: "Февраль",
    3: "Март",
    4: "Апрель",
    5: "Май",
    6: "Июнь",
    7: "Июль",
    8: "Август",
    9: "Сентябрь",
    10: "Октябрь",
    11: "Ноябрь",
    12: "Декабрь",
}

ROMAN_MONTHS = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"]
REQUIRED_METEO_COLS = {"Станция", "Дата", "Сред", "Макс", "Мин"}

print("Рабочая папка:", os.getcwd())
print("Папка data:", os.path.abspath(DATA_DIR))
print("Папка CADASTRE:", os.path.abspath(CADASTRE_DIR))


# 2. ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
def slugify(text: str) -> str:
    text = str(text).strip().lower().replace("ё", "е")
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = re.sub(r"[^a-zа-я0-9]+", "_", text, flags=re.IGNORECASE)
    return text.strip("_") or "unknown"


COMMON_PREFIXES = [
    r"^г\.?\s+",
    r"^гор\.?\s+",
    r"^город\s+",
    r"^ст\.?\s+",
    r"^станция\s+",
    r"^пос\.?\s+",
    r"^п\.?\s+",
    r"^с\.?\s+",
    r"^село\s+",
]


def normalize_station_name(value) -> str:
    s = str(value).strip().lower().replace("ё", "е")
    s = s.replace("№", " ")
    s = re.sub(r"\s+", " ", s)
    for pattern in COMMON_PREFIXES:
        s = re.sub(pattern, "", s)
    s = re.sub(r"[^a-zа-я0-9\s-]", " ", s, flags=re.IGNORECASE)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def discover_excel_files(folder: str):
    if not os.path.isdir(folder):
        raise FileNotFoundError(f"Папка не найдена: {folder}")
    files = sorted(glob.glob(os.path.join(folder, "**", "*.xlsx"), recursive=True))
    if not files:
        raise FileNotFoundError(f"В папке {folder} не найдено ни одного .xlsx файла")
    return files


def try_read_excel_variants(file_path, skiprows_options=(2, 0, 1, 3)):
    last_error = None
    for skip in skiprows_options:
        try:
            df = pd.read_excel(file_path, skiprows=skip)
            df.columns = [str(c).strip() for c in df.columns]
            return df, skip
        except Exception as e:
            last_error = e
    raise ValueError(f"Не удалось открыть файл {file_path}: {last_error}")


def try_read_meteo_file(file_path):
    best_df = None
    best_score = -1

    for skip in (2, 0, 1, 3):
        try:
            df = pd.read_excel(file_path, skiprows=skip)
            df.columns = [str(c).strip() for c in df.columns]
            score = sum(col in df.columns for col in REQUIRED_METEO_COLS)
            if score > best_score:
                best_df = df.copy()
                best_score = score
            if REQUIRED_METEO_COLS.issubset(df.columns):
                return df
        except Exception:
            continue

    if best_df is not None:
        raise ValueError(
            f"Не удалось корректно прочитать метеофайл {os.path.basename(file_path)}. "
            f"Найдены столбцы: {best_df.columns.tolist()}"
        )
    raise ValueError(f"Не удалось открыть метеофайл {os.path.basename(file_path)}")


def detect_cadastre_station_column(df: pd.DataFrame) -> str:
    candidates = [
        "Станция", "станция", "Наименование станции", "Наименование", "Пункт", "Населенный пункт"
    ]
    for col in candidates:
        if col in df.columns:
            return col
    return df.columns[0]


def file_has_cadastre_structure(df: pd.DataFrame) -> bool:
    cols = {str(c).strip() for c in df.columns}
    month_count = sum(m in cols for m in ROMAN_MONTHS)
    return month_count >= 10


def build_meteo_dataframe(meteo_files):
    frames = []
    bad_files = []

    for file_path in meteo_files:
        try:
            df_part = try_read_meteo_file(file_path)
            df_part["__source_file__"] = os.path.basename(file_path)
            df_part["__source_path__"] = file_path
            frames.append(df_part)
            print(f"[OK] Метео: {os.path.basename(file_path)}")
        except Exception as e:
            print(f"[SKIP] Метео: {os.path.basename(file_path)} -> {e}")
            bad_files.append((file_path, str(e)))

    if not frames:
        raise ValueError("Не удалось прочитать ни одного метеофайла")

    full_df = pd.concat(frames, ignore_index=True)
    full_df.columns = [str(c).strip() for c in full_df.columns]

    for col in ["Станция", "Дата", "Сред", "Макс", "Мин"]:
        if col not in full_df.columns:
            raise ValueError(f"После объединения не найден обязательный столбец: {col}")

    full_df["Станция"] = full_df["Станция"].astype(str).str.strip()
    full_df["Станция_norm"] = full_df["Станция"].map(normalize_station_name)
    full_df["Дата"] = pd.to_datetime(full_df["Дата"], errors="coerce")
    full_df["Сред"] = pd.to_numeric(full_df["Сред"], errors="coerce")
    full_df["Макс"] = pd.to_numeric(full_df["Макс"], errors="coerce")
    full_df["Мин"] = pd.to_numeric(full_df["Мин"], errors="coerce")

    full_df = full_df.dropna(subset=["Дата", "Сред"]).copy()
    full_df["Год"] = full_df["Дата"].dt.year
    full_df["Месяц"] = full_df["Дата"].dt.month

    return full_df, bad_files


def build_cadastre_index(cadastre_files):
    rows = []
    bad_files = []

    for file_path in cadastre_files:
        success = False
        for skip in (2, 0, 1, 3):
            try:
                df = pd.read_excel(file_path, skiprows=skip)
                df.columns = [str(c).strip() for c in df.columns]
                if not file_has_cadastre_structure(df):
                    continue

                station_col = detect_cadastre_station_column(df)
                temp = df.copy()
                temp[station_col] = temp[station_col].astype(str).str.strip()
                temp = temp[temp[station_col].notna()].copy()
                temp["__station__"] = temp[station_col]
                temp["__station_norm__"] = temp[station_col].map(normalize_station_name)
                temp["__source_file__"] = os.path.basename(file_path)
                temp["__source_path__"] = file_path
                temp["__skiprows__"] = skip
                rows.append(temp)
                success = True
                print(f"[OK] Кадастр: {os.path.basename(file_path)}")
                break
            except Exception:
                continue

        if not success:
            print(f"[SKIP] Кадастр: {os.path.basename(file_path)}")
            bad_files.append(file_path)

    if not rows:
        raise ValueError("Не удалось прочитать ни одного файла кадастра")

    cadastre_df = pd.concat(rows, ignore_index=True)
    cadastre_df = cadastre_df[cadastre_df["__station_norm__"] != ""].copy()
    return cadastre_df, bad_files


def resolve_query_to_station(query: str, available_names):
    """
    Возвращает лучшее совпадение из available_names.
    Логика:
    1. точное совпадение после нормализации
    2. contains в обе стороны
    3. difflib по похожести
    """
    q_norm = normalize_station_name(query)
    if not q_norm:
        return None

    norm_to_originals = {}
    for name in available_names:
        norm_to_originals.setdefault(normalize_station_name(name), []).append(name)

    if q_norm in norm_to_originals:
        return norm_to_originals[q_norm][0]

    contains_matches = []
    for norm_name, originals in norm_to_originals.items():
        if q_norm in norm_name or norm_name in q_norm:
            contains_matches.extend(originals)
    if contains_matches:
        contains_matches = sorted(set(contains_matches), key=lambda x: len(x))
        return contains_matches[0]

    close = difflib.get_close_matches(q_norm, list(norm_to_originals.keys()), n=1, cutoff=FUZZY_CUTOFF)
    if close:
        return norm_to_originals[close[0]][0]

    return None


def add_linear_trend(ax, x, y, label_prefix="Тренд", linestyle="--", unit="°C/год"):
    x = np.array(x, dtype=float)
    y = np.array(y, dtype=float)

    mask = ~np.isnan(x) & ~np.isnan(y)
    x = x[mask]
    y = y[mask]

    if len(x) < 2:
        return np.nan

    z = np.polyfit(x, y, 1)
    p = np.poly1d(z)
    ax.plot(x, p(x), linestyle=linestyle, linewidth=2, label=f"{label_prefix} ({z[0]:.3f} {unit})")
    return z[0]


def add_linear_trend_custom_x(ax, x_numeric, y, x_for_plot, label_prefix="Тренд", linestyle="--", unit="°C/мес."):
    x_numeric = np.array(x_numeric, dtype=float)
    y = np.array(y, dtype=float)

    mask = ~np.isnan(x_numeric) & ~np.isnan(y)
    x_numeric = x_numeric[mask]
    y = y[mask]

    if len(x_numeric) < 2:
        return np.nan

    z = np.polyfit(x_numeric, y, 1)
    p = np.poly1d(z)
    ax.plot(x_for_plot, p(x_numeric), linestyle=linestyle, linewidth=2, label=f"{label_prefix} ({z[0]:.3f} {unit})")
    return z[0]


def get_season(month):
    if month in [12, 1, 2]:
        return "Зима"
    if month in [3, 4, 5]:
        return "Весна"
    if month in [6, 7, 8]:
        return "Лето"
    return "Осень"


def save_plot(fig, path):
    plt.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def load_cadastre_for_city(cadastre_df, city_name):
    city_norm = normalize_station_name(city_name)
    rows = cadastre_df[cadastre_df["__station_norm__"] == city_norm].copy()

    if rows.empty:
        raise ValueError(f"В кадастре не найдена станция: {city_name}")

    row = rows.iloc[0]
    monthly_values = []

    for m in ROMAN_MONTHS:
        if m not in row.index:
            raise ValueError(f"В кадастре отсутствует столбец месяца: {m}")
        monthly_values.append(pd.to_numeric(row[m], errors="coerce"))

    annual_mean = pd.to_numeric(row.get("Год", np.nan), errors="coerce")
    source_file = row["__source_file__"]
    return monthly_values, annual_mean, source_file


# 3. ПОИСК ФАЙЛОВ В ДВУХ ПАПКАХ
meteo_files = discover_excel_files(DATA_DIR)
cadastre_files = discover_excel_files(CADASTRE_DIR)

print("\nНайдено метеофайлов:", len(meteo_files))
print("Найдено файлов кадастра:", len(cadastre_files))


# 4. ЧТЕНИЕ И ИНДЕКСАЦИЯ
full_df, bad_meteo_files = build_meteo_dataframe(meteo_files)
cadastre_df, bad_cadastre_files = build_cadastre_index(cadastre_files)

meteo_station_map = (
    full_df[["Станция", "Станция_norm"]]
    .drop_duplicates()
    .sort_values("Станция")
)

cadastre_station_map = (
    cadastre_df[["__station__", "__station_norm__"]]
    .drop_duplicates()
    .rename(columns={"__station__": "Станция", "__station_norm__": "Станция_norm"})
    .sort_values("Станция")
)

meteo_norm_to_original = (
    meteo_station_map.groupby("Станция_norm")["Станция"].first().to_dict()
)
cadastre_norm_to_original = (
    cadastre_station_map.groupby("Станция_norm")["Станция"].first().to_dict()
)

common_norm_names = sorted(set(meteo_norm_to_original) & set(cadastre_norm_to_original))
all_common_cities = [meteo_norm_to_original[n] for n in common_norm_names]

print("\nУникальных станций в метеоданных:", len(meteo_station_map))
print("Уникальных станций в кадастре:", len(cadastre_station_map))
print("Совпадающих станций между data и CADASTRE:", len(all_common_cities))

if CITY_QUERIES:
    selected_cities = []
    unresolved_queries = []

    for query in CITY_QUERIES:
        matched = resolve_query_to_station(query, all_common_cities)
        if matched is None:
            unresolved_queries.append(query)
            print(f"[NOT FOUND] '{query}' -> совпадение не найдено")
        else:
            selected_cities.append(matched)
            print(f"[MATCH] '{query}' -> '{matched}'")

    selected_cities = sorted(set(selected_cities))
else:
    selected_cities = all_common_cities
    unresolved_queries = []

if not selected_cities:
    raise ValueError("Не найдено ни одного города для обработки")

print("\nБудут обработаны города:")
for city in selected_cities:
    print("-", city)


# 5. ОБРАБОТКА КАЖДОГО ГОРОДА
processed_cities = []
not_found_in_meteo = []
not_found_in_cadastre = []

for city_name in selected_cities:
    print("\n" + "=" * 70)
    print(f"Обработка города: {city_name}")

    city_norm = normalize_station_name(city_name)
    city_df = full_df[full_df["Станция_norm"] == city_norm].copy()

    if city_df.empty:
        print(f"Пропуск: данных в метеофайлах по станции '{city_name}' не найдено.")
        not_found_in_meteo.append(city_name)
        continue

    text = city_name
    translated = translator.translate(text, src='ru', dest='en')
    city_df = city_df.sort_values("Дата").copy()
    output_dir = f"{RESULT_PREFIX}_{translated.text.lower()}"
    os.makedirs(output_dir, exist_ok=True)

    print("Папка результатов:", os.path.abspath(output_dir))
    print("Количество строк:", len(city_df))
    print("Файлы-источники (метео):", ", ".join(sorted(city_df["__source_file__"].dropna().unique().tolist())))

    # 5.1 Средняя температура по годам
    yearly_avg = city_df.groupby("Год")["Сред"].mean().reset_index()
    yearly_avg.columns = ["Год", f"Средняя температура, °C ({city_name})"]

    years = yearly_avg["Год"].values
    temperatures = yearly_avg[f"Средняя температура, °C ({city_name})"].values

    if len(years) >= 2:
        z = np.polyfit(years, temperatures, 1)
        trend_per_year = z[0]
        trend_per_10_years = z[0] * 10
    else:
        trend_per_year = np.nan
        trend_per_10_years = np.nan

    trend_df = pd.DataFrame({
        "Город": [city_name],
        "Показатель": ["Линейный тренд средней годовой температуры"],
        "Значение, °C/год": [trend_per_year],
        "Значение, °C/10 лет": [trend_per_10_years],
    })

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(years, temperatures, marker="o", label="Средняя температура")
    add_linear_trend(ax, years, temperatures, label_prefix="Линейный тренд")
    ax.set_xlabel("Год")
    ax.set_ylabel("Средняя температура, °C")
    ax.set_title(f"Средняя годовая температура, {city_name}")
    ax.legend()
    ax.grid(True)
    save_plot(fig, os.path.join(output_dir, f"yearly_temperature_{slugify(city_name)}.png"))

    # 5.2 Максимальная и минимальная температура
    max_temp = city_df["Макс"].max()
    min_temp = city_df["Мин"].min()

    extremes_df = pd.DataFrame({
        "Город": [city_name, city_name],
        "Показатель": ["Максимальная температура", "Минимальная температура"],
        "Значение, °C": [max_temp, min_temp],
    })

    # 5.3 Самый жаркий и самый холодный день
    hottest_index = city_df["Макс"].idxmax()
    coldest_index = city_df["Мин"].idxmin()

    hottest_day = city_df.loc[hottest_index, "Дата"]
    coldest_day = city_df.loc[coldest_index, "Дата"]
    hottest_temp = city_df.loc[hottest_index, "Макс"]
    coldest_temp = city_df.loc[coldest_index, "Мин"]

    extreme_days_df = pd.DataFrame({
        "Город": [city_name, city_name],
        "Показатель": ["Самый жаркий день", "Самый холодный день"],
        "Дата": [hottest_day.strftime("%Y-%m-%d"), coldest_day.strftime("%Y-%m-%d")],
        "Температура, °C": [hottest_temp, coldest_temp],
    })

    # 5.4 Средняя температура по месяцам
    monthly_avg = city_df.groupby("Месяц")["Сред"].mean().reset_index()
    monthly_avg.columns = ["Номер месяца", f"Средняя температура, °C ({city_name})"]
    monthly_avg["Месяц"] = monthly_avg["Номер месяца"].map(month_names_ru)
    monthly_avg = monthly_avg[["Номер месяца", "Месяц", f"Средняя температура, °C ({city_name})"]]

    fig, ax = plt.subplots(figsize=(11, 6))
    ax.plot(monthly_avg["Месяц"], monthly_avg[f"Средняя температура, °C ({city_name})"], marker="o", label="Средняя температура")
    add_linear_trend_custom_x(
        ax=ax,
        x_numeric=monthly_avg["Номер месяца"].values,
        y=monthly_avg[f"Средняя температура, °C ({city_name})"].values,
        x_for_plot=monthly_avg["Месяц"],
        label_prefix="Линейный тренд",
    )
    ax.set_xlabel("Месяц")
    ax.set_ylabel("Средняя температура, °C")
    ax.set_title(f"Средняя месячная температура за весь период, {city_name}")
    ax.grid(True)
    ax.legend()
    plt.xticks(rotation=45)
    save_plot(fig, os.path.join(output_dir, f"monthly_temperature_{slugify(city_name)}.png"))

    # 5.5 Сравнение с кадастром
    try:
        cadastre_values, cadastre_year_mean, cadastre_source_file = load_cadastre_for_city(cadastre_df, city_name)

        comparison = monthly_avg.copy()
        comparison["Кадастр, °C"] = cadastre_values
        comparison["Разница, °C"] = comparison[f"Средняя температура, °C ({city_name})"] - comparison["Кадастр, °C"]
        comparison["Город"] = city_name

        fig, ax = plt.subplots(figsize=(11, 6))
        ax.plot(comparison["Месяц"], comparison[f"Средняя температура, °C ({city_name})"], marker="o", label="Мои данные")
        ax.plot(comparison["Месяц"], comparison["Кадастр, °C"], marker="o", label="Кадастр")
        ax.set_xlabel("Месяц")
        ax.set_ylabel("Температура, °C")
        ax.set_title(f"Сравнение среднемесячной температуры, {city_name}")
        ax.legend()
        ax.grid(True)
        plt.xticks(rotation=45)
        save_plot(fig, os.path.join(output_dir, f"cadastre_comparison_{slugify(city_name)}.png"))

        annual_temp_from_months = monthly_avg[f"Средняя температура, °C ({city_name})"].mean()
        annual_comparison_df = pd.DataFrame({
            "Город": [city_name, city_name],
            "Показатель": [
                "Среднегодовая температура (среднее из 12 месяцев)",
                "Среднегодовая температура по кадастру",
            ],
            "Значение, °C": [round(annual_temp_from_months, 2), round(cadastre_year_mean, 2)],
        })

    except Exception as e:
        print(f"Предупреждение: не удалось сравнить с кадастром для '{city_name}': {e}")
        comparison = pd.DataFrame()
        annual_comparison_df = pd.DataFrame()
        not_found_in_cadastre.append(city_name)

    # 5.6 Климатические экстремумы
    warmest_year_row = yearly_avg.loc[yearly_avg[f"Средняя температура, °C ({city_name})"].idxmax()]
    coldest_year_row = yearly_avg.loc[yearly_avg[f"Средняя температура, °C ({city_name})"].idxmin()]
    warmest_month_row = monthly_avg.loc[monthly_avg[f"Средняя температура, °C ({city_name})"].idxmax()]
    coldest_month_row = monthly_avg.loc[monthly_avg[f"Средняя температура, °C ({city_name})"].idxmin()]

    climate_extremes_df = pd.DataFrame({
        "Город": [city_name, city_name, city_name, city_name],
        "Показатель": ["Самый тёплый год", "Самый холодный год", "Самый тёплый месяц", "Самый холодный месяц"],
        "Период": [
            int(warmest_year_row["Год"]),
            int(coldest_year_row["Год"]),
            warmest_month_row["Месяц"],
            coldest_month_row["Месяц"],
        ],
        "Средняя температура, °C": [
            warmest_year_row[f"Средняя температура, °C ({city_name})"],
            coldest_year_row[f"Средняя температура, °C ({city_name})"],
            warmest_month_row[f"Средняя температура, °C ({city_name})"],
            coldest_month_row[f"Средняя температура, °C ({city_name})"],
        ],
    })

    # 5.7 Анализ по сезонам
    city_df["Сезон"] = city_df["Месяц"].apply(get_season)
    city_df["Сезонный год"] = city_df["Год"]
    city_df.loc[city_df["Месяц"] == 12, "Сезонный год"] = city_df["Год"] + 1

    seasonal_avg = city_df.groupby(["Сезонный год", "Сезон"])["Сред"].mean().reset_index()
    seasonal_avg.columns = ["Сезонный год", "Сезон", f"Средняя температура, °C ({city_name})"]

    if not seasonal_avg.empty:
        min_year = seasonal_avg["Сезонный год"].min()
        seasonal_avg = seasonal_avg[~((seasonal_avg["Сезон"] == "Зима") & (seasonal_avg["Сезонный год"] == min_year))].copy()

    seasons = ["Зима", "Весна", "Лето", "Осень"]
    season_trends = []

    for s in seasons:
        data = seasonal_avg[seasonal_avg["Сезон"] == s].sort_values("Сезонный год")
        if data.empty:
            continue

        fig, ax = plt.subplots(figsize=(10, 6))
        ax.plot(data["Сезонный год"], data[f"Средняя температура, °C ({city_name})"], marker="o", label=s)
        slope = add_linear_trend(
            ax,
            data["Сезонный год"].values,
            data[f"Средняя температура, °C ({city_name})"].values,
            label_prefix=f"Тренд: {s}",
        )
        season_trends.append({
            "Город": city_name,
            "Сезон": s,
            "Тренд, °C/год": slope,
            "Тренд, °C/10 лет": slope * 10 if pd.notna(slope) else np.nan,
        })

        ax.set_xlabel("Год")
        ax.set_ylabel("Средняя температура, °C")
        ax.set_title(f"{s}: изменение температуры по годам, {city_name}")
        ax.grid(True)
        ax.legend()
        save_plot(fig, os.path.join(output_dir, f"{slugify(s)}_temperature_{slugify(city_name)}.png"))

    season_trends_df = pd.DataFrame(season_trends)

    fig, ax = plt.subplots(figsize=(12, 7))
    for s in seasons:
        data = seasonal_avg[seasonal_avg["Сезон"] == s].sort_values("Сезонный год")
        if not data.empty:
            ax.plot(data["Сезонный год"], data[f"Средняя температура, °C ({city_name})"], marker="o", label=s)

    ax.set_xlabel("Год")
    ax.set_ylabel("Средняя температура, °C")
    ax.set_title(f"Изменение температуры по сезонам, {city_name}")
    ax.legend()
    ax.grid(True)
    save_plot(fig, os.path.join(output_dir, f"all_seasons_temperature_{slugify(city_name)}.png"))

    # 5.8 Сохранение Excel
    excel_path = os.path.join(output_dir, f"temperature_analysis_{slugify(city_name)}.xlsx")
    with pd.ExcelWriter(excel_path, engine="openpyxl") as writer:
        yearly_avg.to_excel(writer, sheet_name="Средняя_по_годам", index=False)
        monthly_avg.to_excel(writer, sheet_name="Средняя_по_месяцам", index=False)
        if not comparison.empty:
            comparison.to_excel(writer, sheet_name="Сравнение_кадастр", index=False)
        seasonal_avg.to_excel(writer, sheet_name="Средняя_по_сезонам", index=False)
        extremes_df.to_excel(writer, sheet_name="Макс_и_мин", index=False)
        extreme_days_df.to_excel(writer, sheet_name="Экстремальные_дни", index=False)
        trend_df.to_excel(writer, sheet_name="Общий_тренд", index=False)
        season_trends_df.to_excel(writer, sheet_name="Тренды_по_сезонам", index=False)

    print("Готово:", excel_path)
    processed_cities.append(city_name)


# 6. ОБЩИЙ ОТЧЁТ ПО ПОИСКУ СОВПАДЕНИЙ
matching_report = pd.DataFrame({
    "Станция_norm": common_norm_names,
    "Название_в_data": [meteo_norm_to_original[n] for n in common_norm_names],
    "Название_в_CADASTRE": [cadastre_norm_to_original[n] for n in common_norm_names],
})
matching_report.to_excel("matched_cities_report.xlsx", index=False)

print("\n" + "=" * 70)
print("ОБРАБОТКА ЗАВЕРШЕНА")
print("Успешно обработаны города:", len(processed_cities))
for city in processed_cities:
    print("-", city)

if unresolved_queries:
    print("\nЗапросы, которые не удалось сопоставить:")
    for q in unresolved_queries:
        print("-", q)

if not_found_in_meteo:
    print("\nНе найдены в метеоданных:")
    for city in sorted(set(not_found_in_meteo)):
        print("-", city)

if not_found_in_cadastre:
    print("\nНе найдены в кадастре:")
    for city in sorted(set(not_found_in_cadastre)):
        print("-", city)

if bad_meteo_files:
    print("\nПроблемные метеофайлы:")
    for file_path, err in bad_meteo_files:
        print(f"- {os.path.basename(file_path)} -> {err}")

if bad_cadastre_files:
    print("\nПроблемные файлы кадастра:")
    for file_path in bad_cadastre_files:
        print(f"- {os.path.basename(file_path)}")

print("\nСохранён общий отчёт по совпадающим городам: matched_cities_report.xlsx")
