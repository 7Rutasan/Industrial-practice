import os
import re
import glob
import difflib
import unicodedata
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from googletrans import Translator

translator = Translator()

plt.rcParams["font.family"] = "DejaVu Sans"
plt.rcParams["axes.unicode_minus"] = False

# 1. НАСТРОЙКИ
DATA_DIR = "data"

# Пустое множество -> никакие листы не исключаются
EXCLUDED_SHEETS = set()

# Если список пустой -> обработать все найденные станции
CITY_QUERIES = [
    # "Павлодар",
    # "Экибастуз",
]

month_names_ru = {
    1: "Январь",
    2: "Февраль",
    3: "Март",
    4: "Апрель",
    5: "Май",
    6: "Июнь",
    7: "Июль",
    8: "Август",
    9: "Сентябрь",
    10: "Октябрь",
    11: "Ноябрь",
    12: "Декабрь",
}


# 2. ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
def slugify(text: str) -> str:
    text = str(text).strip().lower()
    replacements = {
        "ә": "a", "ғ": "g", "қ": "k", "ң": "n", "ө": "o", "ұ": "u", "ү": "u", "һ": "h", "і": "i",
        "ё": "e", "ж": "zh", "ц": "ts", "ч": "ch", "ш": "sh", "щ": "sch", "ю": "yu", "я": "ya",
        "ы": "y", "э": "e",
    }
    for src, dst in replacements.items():
        text = text.replace(src, dst)
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = re.sub(r"[^a-zA-Z0-9а-яА-Я]+", "_", text)
    text = re.sub(r"_+", "_", text).strip("_")
    return text or "city"


def normalize_station_name(s: str) -> str:
    s = str(s).strip().lower().replace("ё", "е")
    s = re.sub(r"\s+", " ", s)
    return s


def simplify_for_match(s: str) -> str:
    s = normalize_station_name(s)
    s = re.sub(r"[^\w\s-]", "", s)
    return s


def should_skip_sheet(sheet_name: str) -> bool:
    clean = str(sheet_name).strip().lower()
    return any(excl in clean for excl in EXCLUDED_SHEETS)


def discover_excel_files(root_dir: str):
    if not os.path.isdir(root_dir):
        return []
    files = glob.glob(os.path.join(root_dir, "**", "*.xlsx"), recursive=True)
    return sorted([f for f in files if not os.path.basename(f).startswith("~$")])


def add_linear_trend(ax, x, y, label_prefix="Тренд", linestyle="--"):
    x = np.array(x, dtype=float)
    y = np.array(y, dtype=float)
    mask = ~np.isnan(x) & ~np.isnan(y)
    x = x[mask]
    y = y[mask]
    if len(x) < 2:
        return np.nan
    z = np.polyfit(x, y, 1)
    p = np.poly1d(z)
    ax.plot(x, p(x), linestyle=linestyle, linewidth=2, label=f"{label_prefix} ({z[0]:.3f} мм/год)")
    return z[0]


def add_linear_trend_custom_x(ax, x_numeric, y, x_for_plot, label_prefix="Тренд", linestyle="--"):
    x_numeric = np.array(x_numeric, dtype=float)
    y = np.array(y, dtype=float)
    mask = ~np.isnan(x_numeric) & ~np.isnan(y)
    x_numeric = x_numeric[mask]
    y = y[mask]
    if len(x_numeric) < 2:
        return np.nan
    z = np.polyfit(x_numeric, y, 1)
    p = np.poly1d(z)
    ax.plot(x_for_plot, p(x_numeric), linestyle=linestyle, linewidth=2, label=f"{label_prefix} ({z[0]:.3f} мм/мес.)")
    return z[0]


def get_season(month):
    if month in [12, 1, 2]:
        return "Зима"
    if month in [3, 4, 5]:
        return "Весна"
    if month in [6, 7, 8]:
        return "Лето"
    return "Осень"


def save_plot(fig, path):
    plt.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def try_read_precip_sheet(file_path: str, sheet_name: str):
    required_cols = {"Станция", "Дата", "Сумма"}

    for skiprows in (2, 0):
        try:
            df = pd.read_excel(file_path, sheet_name=sheet_name, skiprows=skiprows)
            df.columns = [str(c).strip() for c in df.columns]
            if required_cols.issubset(set(df.columns)):
                return df
        except Exception:
            pass
    return None


def read_all_precip_data(data_dir: str):
    data_files = discover_excel_files(data_dir)

    if not data_files:
        raise FileNotFoundError(f"В папке '{data_dir}' не найдены xlsx-файлы.")

    frames = []
    skipped_sheets_log = []
    unreadable_files = []

    for file_path in data_files:
        file_loaded = False
        try:
            xls = pd.ExcelFile(file_path)
        except Exception as e:
            unreadable_files.append((file_path, str(e)))
            continue

        for sheet in xls.sheet_names:
            if should_skip_sheet(sheet):
                skipped_sheets_log.append((file_path, sheet, "исключённый лист"))
                continue

            df_part = try_read_precip_sheet(file_path, sheet)
            if df_part is None:
                continue

            file_loaded = True
            df_part["__source_file__"] = os.path.basename(file_path)
            df_part["__source_sheet__"] = sheet
            frames.append(df_part)

        if not file_loaded:
            unreadable_files.append((file_path, "не найден лист со столбцами: Станция, Дата, Сумма"))

    if not frames:
        raise ValueError("Не удалось извлечь данные осадков ни из одного файла.")

    full_df = pd.concat(frames, ignore_index=True)
    full_df.columns = [str(c).strip() for c in full_df.columns]

    full_df["Станция"] = full_df["Станция"].astype(str).str.strip()
    full_df["Дата"] = pd.to_datetime(full_df["Дата"], errors="coerce")
    full_df["Осадки"] = pd.to_numeric(full_df["Сумма"], errors="coerce")

    full_df = full_df.dropna(subset=["Дата", "Осадки"]).copy()
    full_df["Год"] = full_df["Дата"].dt.year
    full_df["Месяц"] = full_df["Дата"].dt.month

    return full_df, skipped_sheets_log, unreadable_files


def resolve_requested_cities(city_queries, all_cities):
    if not city_queries:
        return sorted(all_cities), []

    resolved = []
    not_resolved = []
    normalized_candidates = {simplify_for_match(c): c for c in all_cities}
    candidate_keys = list(normalized_candidates.keys())

    for query in city_queries:
        q = simplify_for_match(query)

        if q in normalized_candidates:
            resolved.append(normalized_candidates[q])
            continue

        partial_hits = [normalized_candidates[k] for k in candidate_keys if q and (q in k or k in q)]
        if partial_hits:
            resolved.append(partial_hits[0])
            continue

        fuzzy = difflib.get_close_matches(q, candidate_keys, n=1, cutoff=0.6)
        if fuzzy:
            resolved.append(normalized_candidates[fuzzy[0]])
        else:
            not_resolved.append(query)

    final_resolved = []
    seen = set()
    for city in resolved:
        if city not in seen:
            final_resolved.append(city)
            seen.add(city)

    return final_resolved, not_resolved


# 3. ЗАГРУЗКА ДАННЫХ
print("Рабочая папка:", os.getcwd())
print("Папка data:", os.path.abspath(DATA_DIR))

full_df, skipped_sheets_log, unreadable_files = read_all_precip_data(DATA_DIR)
all_data_cities = sorted(full_df["Станция"].dropna().astype(str).str.strip().unique().tolist())

print("\nВсего строк после объединения и очистки:", len(full_df))
print("Найдено станций:", len(all_data_cities))

selected_cities, not_resolved_queries = resolve_requested_cities(CITY_QUERIES, all_data_cities)

if not selected_cities:
    raise ValueError("Не удалось определить ни одного города для обработки.")

pd.DataFrame({"Станция": all_data_cities}).to_excel("found_precipitation_cities.xlsx", index=False)

if skipped_sheets_log:
    pd.DataFrame(skipped_sheets_log, columns=["Файл", "Лист", "Причина"]).to_excel(
        "skipped_sheets_precipitation.xlsx", index=False
    )

if unreadable_files:
    pd.DataFrame(unreadable_files, columns=["Файл", "Проблема"]).to_excel(
        "unreadable_precipitation_files.xlsx", index=False
    )


# 4. ОБРАБОТКА КАЖДОЙ СТАНЦИИ
not_found_cities = []
processed_cities = []

for city_name in selected_cities:
    print("\n" + "=" * 70)
    print(f"Обработка станции: {city_name}")

    city_df = full_df[
        full_df["Станция"].map(normalize_station_name) == normalize_station_name(city_name)
    ].copy()

    if city_df.empty:
        print(f"Пропуск: данных по станции '{city_name}' не найдено.")
        not_found_cities.append(city_name)
        continue

    text = city_name
    translated = translator.translate(text, src='ru', dest='en')
    city_df = city_df.sort_values("Дата").copy()
    output_dir = f"precipitation_results_{translated.text.lower()}"
    os.makedirs(output_dir, exist_ok=True)

    print("Папка результатов:", os.path.abspath(output_dir))
    print("Количество строк:", len(city_df))
    print("Файлы-источники:", ", ".join(sorted(city_df["__source_file__"].dropna().unique().tolist())))

    # 4.1 Годовые осадки
    yearly_precip = city_df.groupby("Год")["Осадки"].sum().reset_index()
    yearly_precip.columns = ["Год", f"Годовая сумма осадков, мм ({city_name})"]

    years = yearly_precip["Год"].values
    precip_values = yearly_precip[f"Годовая сумма осадков, мм ({city_name})"].values

    if len(years) >= 2:
        z = np.polyfit(years, precip_values, 1)
        trend_per_year = z[0]
        trend_per_10_years = z[0] * 10
    else:
        trend_per_year = np.nan
        trend_per_10_years = np.nan

    trend_df = pd.DataFrame({
        "Станция": [city_name],
        "Показатель": ["Линейный тренд годовой суммы осадков"],
        "Значение, мм/год": [trend_per_year],
        "Значение, мм/10 лет": [trend_per_10_years],
    })

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(years, precip_values, marker="o", label="Годовая сумма осадков")
    add_linear_trend(ax, years, precip_values, label_prefix="Линейный тренд")
    ax.set_xlabel("Год")
    ax.set_ylabel("Количество осадков, мм")
    ax.set_title(f"Годовая сумма осадков, {city_name}")
    ax.legend()
    ax.grid(True)
    save_plot(fig, os.path.join(output_dir, f"yearly_precipitation_{slugify(city_name)}.png"))

    # 4.2 Экстремумы
    max_precip = city_df["Осадки"].max()
    min_precip = city_df["Осадки"].min()

    extremes_df = pd.DataFrame({
        "Станция": [city_name, city_name],
        "Показатель": ["Максимальное значение осадков", "Минимальное значение осадков"],
        "Значение, мм": [max_precip, min_precip],
    })

    max_precip_index = city_df["Осадки"].idxmax()
    min_precip_index = city_df["Осадки"].idxmin()

    extreme_days_df = pd.DataFrame({
        "Станция": [city_name, city_name],
        "Показатель": ["День с максимальным количеством осадков", "День с минимальным количеством осадков"],
        "Дата": [
            city_df.loc[max_precip_index, "Дата"].strftime("%Y-%m-%d"),
            city_df.loc[min_precip_index, "Дата"].strftime("%Y-%m-%d"),
        ],
        "Количество осадков, мм": [max_precip, min_precip],
    })

    # 4.3 Средние по месяцам
    monthly_precip = city_df.groupby("Месяц")["Осадки"].mean().reset_index()
    monthly_precip.columns = ["Номер месяца", f"Среднее количество осадков, мм ({city_name})"]
    monthly_precip["Месяц"] = monthly_precip["Номер месяца"].map(month_names_ru)
    monthly_precip = monthly_precip[["Номер месяца", "Месяц", f"Среднее количество осадков, мм ({city_name})"]]

    fig, ax = plt.subplots(figsize=(11, 6))
    ax.plot(
        monthly_precip["Месяц"],
        monthly_precip[f"Среднее количество осадков, мм ({city_name})"],
        marker="o",
        label="Средние осадки",
    )
    add_linear_trend_custom_x(
        ax,
        monthly_precip["Номер месяца"].values,
        monthly_precip[f"Среднее количество осадков, мм ({city_name})"].values,
        monthly_precip["Месяц"],
        label_prefix="Линейный тренд",
    )
    ax.set_xlabel("Месяц")
    ax.set_ylabel("Количество осадков, мм")
    ax.set_title(f"Среднее количество осадков по месяцам, {city_name}")
    ax.grid(True)
    ax.legend()
    plt.xticks(rotation=45)
    save_plot(fig, os.path.join(output_dir, f"monthly_precipitation_{slugify(city_name)}.png"))

    # 4.4 Сезоны
    city_df["Сезон"] = city_df["Месяц"].apply(get_season)
    city_df["Сезонный год"] = city_df["Год"]
    city_df.loc[city_df["Месяц"] == 12, "Сезонный год"] = city_df["Год"] + 1

    seasonal_precip = city_df.groupby(["Сезонный год", "Сезон"])["Осадки"].mean().reset_index()
    seasonal_precip.columns = ["Сезонный год", "Сезон", f"Среднее количество осадков, мм ({city_name})"]

    if not seasonal_precip.empty:
        min_season_year = seasonal_precip["Сезонный год"].min()
        seasonal_precip = seasonal_precip[
            ~((seasonal_precip["Сезон"] == "Зима") & (seasonal_precip["Сезонный год"] == min_season_year))
        ].copy()

    seasons = ["Зима", "Весна", "Лето", "Осень"]
    season_trends = []

    for s in seasons:
        data = seasonal_precip[seasonal_precip["Сезон"] == s].sort_values("Сезонный год")
        if data.empty:
            continue

        fig, ax = plt.subplots(figsize=(10, 6))
        ax.plot(
            data["Сезонный год"],
            data[f"Среднее количество осадков, мм ({city_name})"],
            marker="o",
            label=s,
        )
        slope = add_linear_trend(
            ax,
            data["Сезонный год"].values,
            data[f"Среднее количество осадков, мм ({city_name})"].values,
            label_prefix=f"Тренд: {s}",
        )

        season_trends.append({
            "Станция": city_name,
            "Сезон": s,
            "Тренд, мм/год": slope,
            "Тренд, мм/10 лет": slope * 10 if pd.notna(slope) else np.nan,
        })

        ax.set_xlabel("Год")
        ax.set_ylabel("Количество осадков, мм")
        ax.set_title(f"{s}: изменение количества осадков по годам, {city_name}")
        ax.grid(True)
        ax.legend()
        save_plot(fig, os.path.join(output_dir, f"{slugify(s)}_precipitation_{slugify(city_name)}.png"))

    season_trends_df = pd.DataFrame(season_trends)

    fig, ax = plt.subplots(figsize=(12, 7))
    for s in seasons:
        data = seasonal_precip[seasonal_precip["Сезон"] == s].sort_values("Сезонный год")
        if not data.empty:
            ax.plot(
                data["Сезонный год"],
                data[f"Среднее количество осадков, мм ({city_name})"],
                marker="o",
                label=s,
            )
    ax.set_xlabel("Год")
    ax.set_ylabel("Количество осадков, мм")
    ax.set_title(f"Изменение количества осадков по сезонам, {city_name}")
    ax.legend()
    ax.grid(True)
    save_plot(fig, os.path.join(output_dir, f"all_seasons_precipitation_{slugify(city_name)}.png"))

    # 4.5 Сводка по влажным/сухим периодам
    wettest_year_row = yearly_precip.loc[yearly_precip[f"Годовая сумма осадков, мм ({city_name})"].idxmax()]
    driest_year_row = yearly_precip.loc[yearly_precip[f"Годовая сумма осадков, мм ({city_name})"].idxmin()]
    wettest_month_row = monthly_precip.loc[monthly_precip[f"Среднее количество осадков, мм ({city_name})"].idxmax()]
    driest_month_row = monthly_precip.loc[monthly_precip[f"Среднее количество осадков, мм ({city_name})"].idxmin()]

    summary_extremes_df = pd.DataFrame({
        "Станция": [city_name, city_name, city_name, city_name],
        "Показатель": ["Самый влажный год", "Самый сухой год", "Самый влажный месяц", "Самый сухой месяц"],
        "Период": [
            int(wettest_year_row["Год"]),
            int(driest_year_row["Год"]),
            wettest_month_row["Месяц"],
            driest_month_row["Месяц"],
        ],
        "Количество осадков, мм": [
            wettest_year_row[f"Годовая сумма осадков, мм ({city_name})"],
            driest_year_row[f"Годовая сумма осадков, мм ({city_name})"],
            wettest_month_row[f"Среднее количество осадков, мм ({city_name})"],
            driest_month_row[f"Среднее количество осадков, мм ({city_name})"],
        ],
    })

    # 4.6 Excel
    sources_df = city_df[["Станция", "Дата", "Осадки", "__source_file__", "__source_sheet__"]].copy()
    sources_df.columns = ["Станция", "Дата", "Осадки", "Файл_источник", "Лист_источник"]

    excel_path = os.path.join(output_dir, f"precipitation_analysis_{slugify(city_name)}.xlsx")
    with pd.ExcelWriter(excel_path, engine="openpyxl") as writer:
        yearly_precip.to_excel(writer, sheet_name="Годовые_осадки", index=False)
        monthly_precip.to_excel(writer, sheet_name="Осадки_по_месяцам", index=False)
        seasonal_precip.to_excel(writer, sheet_name="Осадки_по_сезонам", index=False)
        extremes_df.to_excel(writer, sheet_name="Макс_и_мин_осадки", index=False)
        extreme_days_df.to_excel(writer, sheet_name="Экстремальные_дни", index=False)
        trend_df.to_excel(writer, sheet_name="Общий_тренд", index=False)
        season_trends_df.to_excel(writer, sheet_name="Тренды_по_сезонам", index=False)

    print("Готово:", excel_path)
    processed_cities.append(city_name)


# 5. ИТОГ
print("\n" + "=" * 70)
print("ОБРАБОТКА ЗАВЕРШЕНА")
print("Успешно обработаны станции:")
for city in processed_cities:
    print("-", city)

if not_found_cities:
    print("\nСтанции, по которым данные не найдены:")
    for city in not_found_cities:
        print("-", city)

if not_resolved_queries:
    print("\nЗапросы, которые не удалось сопоставить:")
    for q in not_resolved_queries:
        print("-", q)